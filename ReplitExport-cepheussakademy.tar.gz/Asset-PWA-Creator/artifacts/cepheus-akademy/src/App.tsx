import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

import { Layout } from "@/components/Layout";
import Home from "@/pages/Home";
import Infracciones from "@/pages/Infracciones";
import Accidente from "@/pages/Accidente";
import Alcoholemia from "@/pages/Alcoholemia";
import Hospitales from "@/pages/Hospitales";
import Abogados from "@/pages/Abogados";
import Biblioteca from "@/pages/Biblioteca";
import Admin from "@/pages/Admin";
import Terminos from "@/pages/Terminos";
import EscuelasConduccion from "@/pages/EscuelasConduccion";
import CentrosDiagnostico from "@/pages/CentrosDiagnostico";
import Documentos from "@/pages/Documentos";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient();

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/infracciones" component={Infracciones} />
        <Route path="/accidente" component={Accidente} />
        <Route path="/alcoholemia" component={Alcoholemia} />
        <Route path="/hospitales" component={Hospitales} />
        <Route path="/abogados" component={Abogados} />
        <Route path="/biblioteca" component={Biblioteca} />
        <Route path="/admin" component={Admin} />
        <Route path="/terminos" component={Terminos} />
        <Route path="/escuelas" component={EscuelasConduccion} />
        <Route path="/centros-diagnostico" component={CentrosDiagnostico} />
        <Route path="/documentos" component={Documentos} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
