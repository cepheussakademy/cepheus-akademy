import { Link, useLocation } from "wouter";
import { Home, ShieldAlert, Scale, Menu, BookOpen, MapPin, Search, Users, Settings, FileText } from "lucide-react";
import { 
  Sheet, 
  SheetContent, 
  SheetHeader, 
  SheetTitle,
  SheetTrigger 
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";

export function BottomNav() {
  const [location] = useLocation();

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 border-t bg-background/80 backdrop-blur-md pb-safe">
      <nav className="flex h-16 items-center justify-around px-2">
        <Link href="/" className="flex flex-col items-center justify-center w-full h-full gap-1 text-muted-foreground hover:text-foreground">
          <div className={`p-1.5 rounded-full ${location === "/" ? "bg-accent/10 text-accent" : ""}`}>
            <Home className="h-5 w-5" />
          </div>
          <span className="text-[10px] font-medium">Inicio</span>
        </Link>
        <Link href="/infracciones" className="flex flex-col items-center justify-center w-full h-full gap-1 text-muted-foreground hover:text-foreground">
          <div className={`p-1.5 rounded-full ${location === "/infracciones" ? "bg-accent/10 text-accent" : ""}`}>
            <Search className="h-5 w-5" />
          </div>
          <span className="text-[10px] font-medium">Infracciones</span>
        </Link>
        <Link href="/accidente" className="flex flex-col items-center justify-center w-full h-full gap-1 text-muted-foreground hover:text-foreground">
          <div className={`p-1.5 rounded-full ${location === "/accidente" ? "bg-accent/10 text-accent" : ""}`}>
            <ShieldAlert className="h-5 w-5" />
          </div>
          <span className="text-[10px] font-medium">Accidente</span>
        </Link>
        <Link href="/biblioteca" className="flex flex-col items-center justify-center w-full h-full gap-1 text-muted-foreground hover:text-foreground">
          <div className={`p-1.5 rounded-full ${location === "/biblioteca" ? "bg-accent/10 text-accent" : ""}`}>
            <BookOpen className="h-5 w-5" />
          </div>
          <span className="text-[10px] font-medium">Biblioteca</span>
        </Link>
        
        <Sheet>
          <SheetTrigger asChild>
            <button className="flex flex-col items-center justify-center w-full h-full gap-1 text-muted-foreground hover:text-foreground cursor-pointer">
              <div className="p-1.5 rounded-full">
                <Menu className="h-5 w-5" />
              </div>
              <span className="text-[10px] font-medium">Más</span>
            </button>
          </SheetTrigger>
          <SheetContent side="bottom" className="rounded-t-2xl border-t h-[80vh]">
            <SheetHeader className="mb-6">
              <SheetTitle>Menú Principal</SheetTitle>
            </SheetHeader>
            <div className="grid grid-cols-2 gap-4">
              <Link href="/alcoholemia">
                <Button variant="outline" className="w-full h-24 flex flex-col gap-2 justify-center border-accent/20 hover:bg-accent/5">
                  <Scale className="h-6 w-6 text-accent" />
                  <span className="text-xs">Alcoholemia</span>
                </Button>
              </Link>
              <Link href="/hospitales">
                <Button variant="outline" className="w-full h-24 flex flex-col gap-2 justify-center">
                  <MapPin className="h-6 w-6 text-primary" />
                  <span className="text-xs">Hospitales</span>
                </Button>
              </Link>
              <Link href="/abogados">
                <Button variant="outline" className="w-full h-24 flex flex-col gap-2 justify-center">
                  <Users className="h-6 w-6 text-primary" />
                  <span className="text-xs">Abogados</span>
                </Button>
              </Link>
              <Link href="/admin">
                <Button variant="outline" className="w-full h-24 flex flex-col gap-2 justify-center">
                  <Settings className="h-6 w-6 text-muted-foreground" />
                  <span className="text-xs">Administración</span>
                </Button>
              </Link>
              <Link href="/terminos" className="col-span-2">
                <Button variant="ghost" className="w-full flex gap-2 justify-center text-muted-foreground">
                  <FileText className="h-4 w-4" />
                  <span className="text-xs">Términos y Responsabilidad</span>
                </Button>
              </Link>
            </div>
          </SheetContent>
        </Sheet>
      </nav>
    </div>
  );
}
