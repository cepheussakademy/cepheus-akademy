import { useState, useEffect } from "react";
import { Download, X, Share, Plus, MoreVertical } from "lucide-react";
import { Button } from "@/components/ui/button";

const DISMISSED_KEY = "cepheus_install_dismissed";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

function isIOS() {
  return /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
}

function isInStandalone() {
  return (
    window.matchMedia("(display-mode: standalone)").matches ||
    (window.navigator as any).standalone === true
  );
}

export function InstallPWA() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [showBanner, setShowBanner]         = useState(false);
  const [showIOSModal, setShowIOSModal]     = useState(false);
  const [installed, setInstalled]           = useState(false);

  useEffect(() => {
    // Already installed or dismissed
    if (isInStandalone()) { setInstalled(true); return; }
    if (localStorage.getItem(DISMISSED_KEY)) return;

    // Android / Chrome — listen for install prompt
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
      setShowBanner(true);
    };
    window.addEventListener("beforeinstallprompt", handler);

    // iOS — show banner if not standalone and not dismissed
    if (isIOS()) setShowBanner(true);

    // Listen for successful install
    window.addEventListener("appinstalled", () => {
      setInstalled(true);
      setShowBanner(false);
    });

    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  const dismiss = () => {
    setShowBanner(false);
    setShowIOSModal(false);
    localStorage.setItem(DISMISSED_KEY, "1");
  };

  const handleInstall = async () => {
    if (deferredPrompt) {
      await deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === "accepted") { setInstalled(true); setShowBanner(false); }
      setDeferredPrompt(null);
    } else if (isIOS()) {
      setShowIOSModal(true);
    }
  };

  if (installed || !showBanner) return null;

  return (
    <>
      {/* Banner */}
      <div className="w-full bg-primary/5 border-b border-primary/10 px-4 py-2.5 flex items-center gap-3 animate-in slide-in-from-top-2 duration-300">
        <div className="bg-accent/10 rounded-lg p-1.5 shrink-0">
          <Download className="h-4 w-4 text-accent" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-xs font-semibold text-foreground leading-tight">Instalar Cepheus Transit</p>
          <p className="text-[10px] text-muted-foreground leading-tight">Agrega la app a tu pantalla de inicio</p>
        </div>
        <Button
          size="sm"
          className="h-7 text-xs bg-accent hover:bg-accent/90 text-white shrink-0 gap-1 px-3"
          onClick={handleInstall}
          data-testid="button-instalar-pwa"
        >
          <Download className="h-3 w-3" /> Instalar
        </Button>
        <button onClick={dismiss} className="shrink-0 text-muted-foreground hover:text-foreground" aria-label="Cerrar">
          <X className="h-4 w-4" />
        </button>
      </div>

      {/* iOS instructions modal */}
      {showIOSModal && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 animate-in fade-in" onClick={() => setShowIOSModal(false)}>
          <div
            className="w-full max-w-lg bg-background rounded-t-2xl p-6 pb-10 shadow-2xl animate-in slide-in-from-bottom-4"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Handle */}
            <div className="w-10 h-1 bg-muted-foreground/30 rounded-full mx-auto mb-5" />

            <h2 className="text-lg font-bold text-center mb-1">Instalar en iPhone / iPad</h2>
            <p className="text-sm text-muted-foreground text-center mb-6">Sigue estos 3 pasos para agregar la app a tu pantalla de inicio:</p>

            <div className="space-y-4">
              <Step num={1} icon={<Share className="h-5 w-5 text-blue-500" />}>
                Toca el botón <strong>Compartir</strong>
                <span className="inline-flex items-center gap-0.5 mx-1 px-1.5 py-0.5 bg-blue-50 dark:bg-blue-950/40 rounded text-blue-600 dark:text-blue-400 text-xs font-medium">
                  <Share className="h-3 w-3" /> Compartir
                </span>
                en la barra inferior del navegador Safari
              </Step>

              <Step num={2} icon={<Plus className="h-5 w-5 text-green-500" />}>
                Desplázate hacia abajo y selecciona{" "}
                <strong>"Agregar a pantalla de inicio"</strong>
              </Step>

              <Step num={3} icon={<Download className="h-5 w-5 text-accent" />}>
                Confirma tocando <strong>"Agregar"</strong> en la esquina superior derecha
              </Step>
            </div>

            <div className="mt-5 p-3 bg-amber-50 dark:bg-amber-950/30 rounded-lg border border-amber-200 dark:border-amber-800">
              <p className="text-xs text-amber-700 dark:text-amber-400 text-center">
                📱 Solo disponible en <strong>Safari</strong>. Si estás usando Chrome u otro navegador, ábrela en Safari primero.
              </p>
            </div>

            <Button className="w-full mt-5 gap-2" onClick={() => setShowIOSModal(false)}>
              Entendido
            </Button>
          </div>
        </div>
      )}
    </>
  );
}

function Step({ num, icon, children }: { num: number; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="flex items-start gap-3">
      <div className="shrink-0 w-7 h-7 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold">
        {num}
      </div>
      <div className="flex items-start gap-2 flex-1">
        <div className="shrink-0 mt-0.5">{icon}</div>
        <p className="text-sm text-muted-foreground leading-relaxed">{children}</p>
      </div>
    </div>
  );
}
