import { ReactNode } from "react";
import { BottomNav } from "./BottomNav";
import { SplashScreen } from "./SplashScreen";
import { InstallPWA } from "./InstallPWA";
import { Sun, Moon } from "lucide-react";
import { useTheme } from "./ThemeToggle";

export function Layout({ children }: { children: ReactNode }) {
  const { theme, setTheme } = useTheme();
  
  return (
    <div className="min-h-[100dvh] bg-background text-foreground pb-20 md:pb-0 flex flex-col">
      <SplashScreen />
      <header className="sticky top-0 z-40 w-full border-b bg-background/80 backdrop-blur-md">
        <div className="flex h-14 items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <div className="rounded-lg bg-accent p-1.5">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
              </svg>
            </div>
            <span className="font-bold tracking-tight text-lg">Cepheus Transit</span>
          </div>
          <button 
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            className="p-2 rounded-full hover:bg-accent/10 text-muted-foreground hover:text-accent transition-colors"
          >
            {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </button>
        </div>
        <InstallPWA />
      </header>
      <main className="flex-1 flex flex-col w-full max-w-lg mx-auto">
        {children}
      </main>
      <BottomNav />
    </div>
  );
}
