import { useState, useEffect } from "react";
import { Settings, Plus, Save, Trash2 } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Checkbox } from "@/components/ui/checkbox";

export default function Admin() {
  const { toast } = useToast();
  const [infracciones, setInfracciones] = useState<any[]>([]);
  const [abogados, setAbogados] = useState<any[]>([]);

  // Simple form states (MVP approach)
  const [infForm, setInfForm] = useState({
    codigo: "", descripcion: "", norma: "", articulo: "", sancion: "", inmovilizacion: false,
    explicacion_ciudadano: "", observaciones_tecnicas: "", jurisprudencia: ""
  });

  const [aboForm, setAbForm] = useState({
    nombre: "", ciudad: "", especialidad: "", telefono: "", whatsapp: "", email: ""
  });

  useEffect(() => {
    // Load existing from localStorage
    const savedInf = localStorage.getItem("admin_infracciones");
    const savedAbo = localStorage.getItem("admin_abogados");
    
    if (savedInf) setInfracciones(JSON.parse(savedInf));
    if (savedAbo) setAbogados(JSON.parse(savedAbo));
  }, []);

  const handleSaveInfraccion = () => {
    if (!infForm.codigo || !infForm.descripcion) {
      toast({ title: "Error", description: "Código y descripción son obligatorios", variant: "destructive" });
      return;
    }
    
    const next = [...infracciones, infForm];
    setInfracciones(next);
    localStorage.setItem("admin_infracciones", JSON.stringify(next));
    setInfForm({ codigo: "", descripcion: "", norma: "", articulo: "", sancion: "", inmovilizacion: false, explicacion_ciudadano: "", observaciones_tecnicas: "", jurisprudencia: "" });
    toast({ title: "Guardado", description: "Infracción guardada correctamente (LocalStorage)" });
  };

  const handleSaveAbogado = () => {
    if (!aboForm.nombre || !aboForm.ciudad) {
      toast({ title: "Error", description: "Nombre y ciudad son obligatorios", variant: "destructive" });
      return;
    }
    
    const next = [...abogados, aboForm];
    setAbogados(next);
    localStorage.setItem("admin_abogados", JSON.stringify(next));
    setAbForm({ nombre: "", ciudad: "", especialidad: "", telefono: "", whatsapp: "", email: "" });
    toast({ title: "Guardado", description: "Abogado guardado correctamente (LocalStorage)" });
  };

  const handleDelete = (type: "infraccion" | "abogado", index: number) => {
    if (type === "infraccion") {
      const next = [...infracciones];
      next.splice(index, 1);
      setInfracciones(next);
      localStorage.setItem("admin_infracciones", JSON.stringify(next));
    } else {
      const next = [...abogados];
      next.splice(index, 1);
      setAbogados(next);
      localStorage.setItem("admin_abogados", JSON.stringify(next));
    }
    toast({ title: "Eliminado", description: "Elemento eliminado" });
  };

  return (
    <div className="flex flex-col h-full animate-in fade-in pb-24">
      <div className="p-6 pb-4 border-b bg-muted/30">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Settings className="h-6 w-6 text-primary" /> Panel de Administración
        </h1>
        <p className="text-muted-foreground text-sm mt-1">
          Modo offline (MVP). Los datos se guardan en el LocalStorage de este navegador.
        </p>
      </div>

      <div className="p-4 flex-1">
        <Tabs defaultValue="infracciones" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-4">
            <TabsTrigger value="infracciones">Infracciones</TabsTrigger>
            <TabsTrigger value="abogados">Abogados</TabsTrigger>
          </TabsList>
          
          <TabsContent value="infracciones" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Añadir Infracción</CardTitle>
                <CardDescription>Agregar nueva infracción a la base de datos local</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="codigo">Código</Label>
                    <Input id="codigo" value={infForm.codigo} onChange={(e) => setInfForm({...infForm, codigo: e.target.value})} placeholder="Ej: C02" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="sancion">Sanción</Label>
                    <Input id="sancion" value={infForm.sancion} onChange={(e) => setInfForm({...infForm, sancion: e.target.value})} placeholder="15 SMLDV" />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="descripcion">Descripción</Label>
                  <Input id="descripcion" value={infForm.descripcion} onChange={(e) => setInfForm({...infForm, descripcion: e.target.value})} />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="norma">Norma</Label>
                    <Input id="norma" value={infForm.norma} onChange={(e) => setInfForm({...infForm, norma: e.target.value})} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="articulo">Artículo</Label>
                    <Input id="articulo" value={infForm.articulo} onChange={(e) => setInfForm({...infForm, articulo: e.target.value})} />
                  </div>
                </div>
                
                <div className="flex items-center space-x-2 py-2">
                  <Checkbox 
                    id="inmovilizacion" 
                    checked={infForm.inmovilizacion} 
                    onCheckedChange={(c) => setInfForm({...infForm, inmovilizacion: !!c})}
                  />
                  <Label htmlFor="inmovilizacion" className="font-semibold text-destructive cursor-pointer">Aplica inmovilización de vehículo</Label>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="exp">Explicación para ciudadano</Label>
                  <Textarea id="exp" value={infForm.explicacion_ciudadano} onChange={(e) => setInfForm({...infForm, explicacion_ciudadano: e.target.value})} />
                </div>
                
                <Button className="w-full" onClick={handleSaveInfraccion}>
                  <Save className="h-4 w-4 mr-2" /> Guardar Infracción
                </Button>
              </CardContent>
            </Card>

            {infracciones.length > 0 && (
              <div className="space-y-2 mt-6">
                <h3 className="font-semibold px-1">Infracciones guardadas localmente</h3>
                {infracciones.map((inf, i) => (
                  <Card key={i} className="p-3 flex justify-between items-center bg-muted/20">
                    <div>
                      <span className="font-bold">{inf.codigo}</span> - <span className="text-sm truncate max-w-[200px] inline-block align-bottom">{inf.descripcion}</span>
                    </div>
                    <Button variant="ghost" size="icon" onClick={() => handleDelete("infraccion", i)} className="text-destructive hover:bg-destructive/10">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="abogados" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Añadir Abogado</CardTitle>
                <CardDescription>Agregar profesional al directorio local</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="nombre">Nombre Completo</Label>
                  <Input id="nombre" value={aboForm.nombre} onChange={(e) => setAbForm({...aboForm, nombre: e.target.value})} />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="ciudad">Ciudad</Label>
                    <Input id="ciudad" value={aboForm.ciudad} onChange={(e) => setAbForm({...aboForm, ciudad: e.target.value})} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="esp">Especialidad</Label>
                    <Input id="esp" value={aboForm.especialidad} onChange={(e) => setAbForm({...aboForm, especialidad: e.target.value})} />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="tel">Teléfono</Label>
                    <Input id="tel" value={aboForm.telefono} onChange={(e) => setAbForm({...aboForm, telefono: e.target.value})} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="wpp">WhatsApp (solo números)</Label>
                    <Input id="wpp" value={aboForm.whatsapp} onChange={(e) => setAbForm({...aboForm, whatsapp: e.target.value})} placeholder="573000000000" />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" value={aboForm.email} onChange={(e) => setAbForm({...aboForm, email: e.target.value})} />
                </div>
                
                <Button className="w-full" onClick={handleSaveAbogado}>
                  <Save className="h-4 w-4 mr-2" /> Guardar Abogado
                </Button>
              </CardContent>
            </Card>

            {abogados.length > 0 && (
              <div className="space-y-2 mt-6">
                <h3 className="font-semibold px-1">Abogados guardados localmente</h3>
                {abogados.map((abo, i) => (
                  <Card key={i} className="p-3 flex justify-between items-center bg-muted/20">
                    <div>
                      <span className="font-bold text-sm">{abo.nombre}</span> <span className="text-xs text-muted-foreground ml-2">({abo.ciudad})</span>
                    </div>
                    <Button variant="ghost" size="icon" onClick={() => handleDelete("abogado", i)} className="text-destructive hover:bg-destructive/10">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
