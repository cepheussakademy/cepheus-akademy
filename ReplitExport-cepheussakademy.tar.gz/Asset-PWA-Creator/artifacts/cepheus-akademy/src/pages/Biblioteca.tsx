import { BookOpen, Search, Scale, FileText, Book, Info, AlertCircle, Bookmark } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function Biblioteca() {
  return (
    <div className="flex flex-col h-full animate-in fade-in pb-24">
      <div className="bg-primary text-primary-foreground p-6 pt-8 pb-10">
        <h1 className="text-2xl font-bold flex items-center gap-2 mb-2">
          <BookOpen className="h-6 w-6" /> Biblioteca Normativa
        </h1>
        <p className="text-primary-foreground/80 text-sm">
          Consulta rápida de legislación, procedimientos y jurisprudencia clave en materia de tránsito en Colombia.
        </p>
      </div>

      <div className="p-4 -mt-6">
        <Card className="shadow-lg border-none overflow-hidden">
          <Accordion type="single" collapsible className="w-full">
            
            <AccordionItem value="item-1" className="border-b-0 px-4">
              <AccordionTrigger className="hover:no-underline py-4">
                <div className="flex items-center gap-3 text-left">
                  <div className="bg-primary/10 p-2 rounded-lg text-primary">
                    <Book className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Código Nacional de Tránsito</h3>
                    <p className="text-xs text-muted-foreground font-normal">Ley 769 de 2002</p>
                  </div>
                </div>
              </AccordionTrigger>
              <AccordionContent className="pb-4 pt-2">
                <div className="space-y-3">
                  <div className="p-3 bg-muted/30 rounded-lg border border-border/50">
                    <h4 className="font-semibold text-sm mb-1 text-primary">Título I: Disposiciones Generales</h4>
                    <p className="text-xs text-muted-foreground">Principios, definiciones y autoridades competentes.</p>
                  </div>
                  <div className="p-3 bg-muted/30 rounded-lg border border-border/50">
                    <h4 className="font-semibold text-sm mb-1 text-primary">Título II: Régimen Nacional</h4>
                    <p className="text-xs text-muted-foreground">Registros, licencias, vehículos, seguros técnicos.</p>
                  </div>
                  <div className="p-3 bg-muted/30 rounded-lg border border-border/50">
                    <h4 className="font-semibold text-sm mb-1 text-primary">Título III: Normas de Comportamiento</h4>
                    <p className="text-xs text-muted-foreground">Reglas generales, peatones, conducción, estacionamiento.</p>
                  </div>
                  <div className="p-3 bg-muted/30 rounded-lg border border-border/50">
                    <h4 className="font-semibold text-sm mb-1 text-primary">Título IV: Sanciones y Procedimientos</h4>
                    <p className="text-xs text-muted-foreground">Tipos de sanciones, multas, inmovilización, comparendos.</p>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>
            
            <div className="h-px bg-border/50 mx-4" />

            <AccordionItem value="item-2" className="border-b-0 px-4">
              <AccordionTrigger className="hover:no-underline py-4">
                <div className="flex items-center gap-3 text-left">
                  <div className="bg-accent/10 p-2 rounded-lg text-accent">
                    <Scale className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Procedimiento Contravencional</h3>
                    <p className="text-xs text-muted-foreground font-normal">Pasos del proceso de multa</p>
                  </div>
                </div>
              </AccordionTrigger>
              <AccordionContent className="pb-4 pt-2">
                <div className="relative pl-4 space-y-4 border-l-2 border-muted ml-2 mt-2">
                  <div className="relative">
                    <div className="absolute -left-[21px] bg-background border-2 border-accent w-3 h-3 rounded-full mt-1" />
                    <h4 className="font-semibold text-sm">1. Orden de Comparendo</h4>
                    <p className="text-xs text-muted-foreground mt-1">Notificación formal de la presunta infracción (en vía o electrónico). No es la sanción definitiva.</p>
                  </div>
                  <div className="relative">
                    <div className="absolute -left-[21px] bg-background border-2 border-accent w-3 h-3 rounded-full mt-1" />
                    <h4 className="font-semibold text-sm">2. Comparecencia (5 días)</h4>
                    <p className="text-xs text-muted-foreground mt-1">Plazo para presentarse. Puede aceptar (y pagar con descuento) o rechazar y solicitar audiencia.</p>
                  </div>
                  <div className="relative">
                    <div className="absolute -left-[21px] bg-background border-2 border-accent w-3 h-3 rounded-full mt-1" />
                    <h4 className="font-semibold text-sm">3. Audiencia Pública</h4>
                    <p className="text-xs text-muted-foreground mt-1">Presentación y contradicción de pruebas ante el inspector de tránsito.</p>
                  </div>
                  <div className="relative">
                    <div className="absolute -left-[21px] bg-background border-2 border-accent w-3 h-3 rounded-full mt-1" />
                    <h4 className="font-semibold text-sm">4. Resolución</h4>
                    <p className="text-xs text-muted-foreground mt-1">Acto administrativo que declara si el investigado es contraventor o lo exonera.</p>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>

            <div className="h-px bg-border/50 mx-4" />

            <AccordionItem value="item-3" className="border-b-0 px-4">
              <AccordionTrigger className="hover:no-underline py-4">
                <div className="flex items-center gap-3 text-left">
                  <div className="bg-destructive/10 p-2 rounded-lg text-destructive">
                    <AlertCircle className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Embriaguez y Sustancias</h3>
                    <p className="text-xs text-muted-foreground font-normal">Ley 1696 de 2013</p>
                  </div>
                </div>
              </AccordionTrigger>
              <AccordionContent className="pb-4 pt-2">
                <div className="space-y-3">
                  <Card className="border-destructive/20 bg-destructive/5 shadow-none">
                    <CardContent className="p-3">
                      <h4 className="font-bold text-sm text-destructive mb-2">Grados de Alcoholemia</h4>
                      <ul className="text-xs space-y-2">
                        <li className="flex justify-between border-b border-border/50 pb-1">
                          <span>Grado 0 (20-39 mg)</span>
                          <span className="font-semibold">90 SMLDV</span>
                        </li>
                        <li className="flex justify-between border-b border-border/50 pb-1">
                          <span>Grado 1 (40-99 mg)</span>
                          <span className="font-semibold">180 SMLDV</span>
                        </li>
                        <li className="flex justify-between border-b border-border/50 pb-1">
                          <span>Grado 2 (100-149 mg)</span>
                          <span className="font-semibold">360 SMLDV</span>
                        </li>
                        <li className="flex justify-between pb-1">
                          <span>Grado 3 (≥ 150 mg)</span>
                          <span className="font-semibold text-destructive">720 SMLDV</span>
                        </li>
                      </ul>
                      <p className="text-[10px] text-muted-foreground mt-2 italic">* Negarse a la prueba se sanciona como Grado 3 (cancelación licencia y multa máxima).</p>
                    </CardContent>
                  </Card>
                </div>
              </AccordionContent>
            </AccordionItem>

            <div className="h-px bg-border/50 mx-4" />

            <AccordionItem value="item-4" className="border-b-0 px-4">
              <AccordionTrigger className="hover:no-underline py-4">
                <div className="flex items-center gap-3 text-left">
                  <div className="bg-blue-500/10 p-2 rounded-lg text-blue-600 dark:text-blue-400">
                    <Bookmark className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Jurisprudencia Destacada</h3>
                    <p className="text-xs text-muted-foreground font-normal">Corte Constitucional</p>
                  </div>
                </div>
              </AccordionTrigger>
              <AccordionContent className="pb-4 pt-2">
                <div className="space-y-4">
                  <div className="bg-muted/30 p-3 rounded-lg border-l-2 border-blue-500">
                    <Badge variant="outline" className="mb-2 bg-background">Sentencia C-038/2020</Badge>
                    <h4 className="font-semibold text-sm mb-1">Fotomultas e Identificación</h4>
                    <p className="text-xs text-muted-foreground">La responsabilidad por infracciones captadas por cámaras recae sobre el conductor, no automáticamente sobre el propietario del vehículo. La autoridad debe probar quién conducía.</p>
                  </div>
                  
                  <div className="bg-muted/30 p-3 rounded-lg border-l-2 border-blue-500">
                    <Badge variant="outline" className="mb-2 bg-background">Sentencia T-051/2016</Badge>
                    <h4 className="font-semibold text-sm mb-1">Debido Proceso en Comparendos</h4>
                    <p className="text-xs text-muted-foreground">Garantiza el derecho a la defensa. La sola firma del comparendo no implica aceptación de culpa, es solo notificación de la orden de presentarse.</p>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>

          </Accordion>
        </Card>
      </div>
    </div>
  );
}
