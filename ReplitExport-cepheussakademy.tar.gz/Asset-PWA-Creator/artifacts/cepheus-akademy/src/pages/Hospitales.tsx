import { useState } from "react";
import { MapPin, Navigation, Phone, Search, Building2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import hospitalesData from "@/data/hospitales.json";
import { useToast } from "@/hooks/use-toast";

export default function Hospitales() {
  const [loading, setLoading] = useState(false);
  const [locationEnabled, setLocationEnabled] = useState(false);
  // En una app real, usaríamos estas coordenadas para ordenar
  // const [userCoords, setUserCoords] = useState<{lat: number, lng: number} | null>(null);
  const { toast } = useToast();

  const handleLocation = () => {
    setLoading(true);
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          // setUserCoords({ lat: position.coords.latitude, lng: position.coords.longitude });
          setLocationEnabled(true);
          setLoading(false);
          toast({
            title: "Ubicación obtenida",
            description: "Mostrando los hospitales más cercanos a tu ubicación.",
          });
        },
        (error) => {
          setLoading(false);
          toast({
            title: "Error de ubicación",
            description: "No pudimos acceder a tu ubicación. Por favor permite el acceso o busca manualmente.",
            variant: "destructive"
          });
        }
      );
    } else {
      setLoading(false);
      toast({
        title: "No soportado",
        description: "Tu navegador no soporta geolocalización.",
        variant: "destructive"
      });
    }
  };

  const openMaps = (address: string, city: string) => {
    const query = encodeURIComponent(`${address}, ${city}`);
    window.open(`https://maps.google.com/?q=${query}`, '_blank');
  };

  // Sort by simulated distance if location is enabled
  const displayData = locationEnabled 
    ? [...hospitalesData].sort((a, b) => a.distancia - b.distancia)
    : hospitalesData;

  return (
    <div className="flex flex-col h-full animate-in fade-in">
      <div className="bg-primary text-primary-foreground p-6 pt-8 pb-10 rounded-b-3xl shadow-lg relative overflow-hidden">
        <div className="absolute top-0 right-0 opacity-10 translate-x-1/4 -translate-y-1/4">
          <Building2 className="w-48 h-48" />
        </div>
        <div className="relative z-10">
          <h1 className="text-2xl font-bold flex items-center gap-2 mb-2">
            <MapPin className="h-6 w-6" /> Centros Médicos
          </h1>
          <p className="text-primary-foreground/80 text-sm mb-6 max-w-sm">
            Encuentra hospitales y clínicas cercanos autorizados para atención de accidentes de tránsito (SOAT).
          </p>
          
          <Button 
            onClick={handleLocation} 
            disabled={loading || locationEnabled}
            variant="secondary"
            className={`w-full font-semibold shadow-md ${locationEnabled ? 'bg-green-500 text-white hover:bg-green-600' : ''}`}
          >
            {loading ? (
              <span className="flex items-center gap-2">Obteniendo ubicación...</span>
            ) : locationEnabled ? (
              <span className="flex items-center gap-2"><MapPin className="w-4 h-4" /> Ubicación Activa</span>
            ) : (
              <span className="flex items-center gap-2"><Navigation className="w-4 h-4" /> Usar mi ubicación actual</span>
            )}
          </Button>
        </div>
      </div>

      <div className="p-4 flex-1 space-y-4 -mt-4 relative z-20 pb-24">
        {displayData.map((hospital, i) => (
          <Card key={i} className="border-primary/10 shadow-sm overflow-hidden animate-in slide-in-from-bottom-4" style={{ animationDelay: `${i * 100}ms` }}>
            <CardContent className="p-0">
              <div className="p-4 border-b">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-bold text-lg leading-tight">{hospital.nombre}</h3>
                  <Badge variant="outline" className="shrink-0 ml-2 bg-primary/5 text-primary border-primary/20">
                    {hospital.distancia} km
                  </Badge>
                </div>
                <div className="flex gap-2 mb-3">
                  <Badge variant="secondary" className="text-[10px]">{hospital.tipo}</Badge>
                  <Badge variant="secondary" className="text-[10px]">{hospital.ciudad}</Badge>
                </div>
                <p className="text-sm text-muted-foreground flex items-start gap-2 mb-2">
                  <MapPin className="w-4 h-4 mt-0.5 shrink-0" />
                  <span>{hospital.direccion}</span>
                </p>
                <p className="text-sm font-medium flex items-center gap-2">
                  <Phone className="w-4 h-4 shrink-0 text-accent" />
                  <a href={`tel:${hospital.telefono.replace(/\D/g, '')}`} className="text-accent hover:underline">
                    {hospital.telefono}
                  </a>
                </p>
              </div>
              <div className="bg-muted/20 p-3">
                <Button 
                  variant="outline" 
                  className="w-full justify-between hover:bg-primary/5 hover:text-primary hover:border-primary/30"
                  onClick={() => openMaps(hospital.direccion, hospital.ciudad)}
                >
                  <span className="font-semibold text-sm">Abrir en Google Maps</span>
                  <Navigation className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
