import { useState } from "react";
import { GraduationCap, MapPin, Navigation, ExternalLink, AlertTriangle, Info, Star, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";

type Estado = "idle" | "buscando" | "listo" | "error";

export default function EscuelasConduccion() {
  const [estado, setEstado] = useState<Estado>("idle");
  const [errorMsg, setErrorMsg] = useState("");

  const abrirEnMaps = (lat: number, lng: number) => {
    // Abre Google Maps centrado en la ubicación del usuario y busca escuelas de conducción cercanas
    const query = encodeURIComponent("escuela de conducción CEA");
    const url = `https://www.google.com/maps/search/${query}/@${lat},${lng},14z`;
    window.open(url, "_blank");
    setEstado("listo");
  };

  const abrirSinUbicacion = () => {
    // Fallback: búsqueda general sin coordenadas
    const url = "https://www.google.com/maps/search/escuela+de+conduccion+CEA+Colombia";
    window.open(url, "_blank");
    setEstado("listo");
  };

  const buscarCercanas = () => {
    if (!navigator.geolocation) {
      setErrorMsg("Tu navegador no soporta geolocalización. Se abrirá una búsqueda general en Google Maps.");
      setEstado("error");
      return;
    }

    setEstado("buscando");
    setErrorMsg("");

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        abrirEnMaps(pos.coords.latitude, pos.coords.longitude);
      },
      (err) => {
        let msg = "No fue posible obtener tu ubicación.";
        if (err.code === 1) msg = "Permiso de ubicación denegado. Puedes activarlo en la configuración de tu navegador.";
        if (err.code === 2) msg = "No se pudo determinar tu ubicación en este momento.";
        if (err.code === 3) msg = "La solicitud de ubicación tardó demasiado.";
        setErrorMsg(msg);
        setEstado("error");
      },
      { timeout: 10000, enableHighAccuracy: true }
    );
  };

  return (
    <div className="flex flex-col h-full animate-in fade-in p-4 pb-24 gap-5">

      {/* Header */}
      <div className="flex flex-col gap-2 bg-gradient-to-br from-primary to-primary/80 text-primary-foreground p-6 rounded-2xl shadow-xl shadow-primary/20">
        <div className="flex items-center gap-3">
          <div className="bg-accent/20 p-2 rounded-xl">
            <GraduationCap className="h-8 w-8 text-accent" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Escuelas de Conducción</h1>
            <p className="text-primary-foreground/75 text-sm">Centros de Enseñanza Automovilística — CEA</p>
          </div>
        </div>
      </div>

      {/* Escuela Destacada */}
      <div className="relative">
        <div className="absolute -top-2.5 left-4 flex items-center gap-1.5 bg-accent text-white text-[10px] font-bold px-2.5 py-0.5 rounded-full shadow-md z-10">
          <Star className="h-3 w-3 fill-white" /> DESTACADA
        </div>
        <Card className="border-2 border-accent/40 shadow-lg pt-2">
          <CardContent className="p-5 flex flex-col gap-4">
            <div className="flex items-start gap-3">
              <div className="bg-accent/10 rounded-xl p-2.5 shrink-0">
                <GraduationCap className="h-7 w-7 text-accent" />
              </div>
              <div className="flex-1 min-w-0">
                <h2 className="font-bold text-base leading-tight">Autodinámico</h2>
                <p className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1">
                  <MapPin className="h-3 w-3 shrink-0" /> Villagorgona, Candelaria — Valle del Cauca
                </p>
              </div>
            </div>

            <div className="flex flex-col gap-2">
              <Button
                className="w-full h-11 bg-[#25D366] hover:bg-[#20bd5a] text-white font-semibold gap-2 text-sm"
                onClick={() =>
                  window.open(
                    "https://wa.me/573145934716?text=Hola%2C%20me%20interesa%20información%20sobre%20los%20cursos%20de%20conducción%20en%20Autodinámico",
                    "_blank"
                  )
                }
                data-testid="button-autodinamico-whatsapp"
              >
                <MessageCircle className="h-4 w-4" /> WhatsApp · 314 593 4716
              </Button>
              <Button
                variant="outline"
                className="w-full h-10 gap-2 text-sm border-blue-400/40 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/30"
                onClick={() =>
                  window.open("https://www.facebook.com/AutodinamicoVillagorgona/", "_blank")
                }
                data-testid="button-autodinamico-facebook"
              >
                <ExternalLink className="h-4 w-4" /> Ver página en Facebook
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Botón principal */}
      <Card className="border-none shadow-lg">
        <CardContent className="p-6 flex flex-col items-center gap-5 text-center">
          <div className="bg-accent/10 rounded-full p-5">
            <Navigation className="h-10 w-10 text-accent" />
          </div>

          <div>
            <h2 className="text-lg font-bold mb-1">Encuentra la escuela más cercana</h2>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Usamos tu ubicación actual para mostrarte en Google Maps los Centros de Enseñanza Automovilística (CEA) más cercanos a ti.
            </p>
          </div>

          <Button
            data-testid="button-buscar-escuelas-cercanas"
            onClick={buscarCercanas}
            disabled={estado === "buscando"}
            className="w-full h-14 text-base font-bold bg-accent hover:bg-accent/90 text-white gap-3"
            size="lg"
          >
            {estado === "buscando" ? (
              <>
                <span className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent" />
                Obteniendo ubicación...
              </>
            ) : (
              <>
                <MapPin className="h-5 w-5" />
                Buscar escuelas cercanas
              </>
            )}
          </Button>

          {estado !== "idle" && estado !== "buscando" && (
            <Button
              variant="outline"
              className="w-full gap-2"
              onClick={abrirSinUbicacion}
              data-testid="button-buscar-sin-ubicacion"
            >
              <ExternalLink className="h-4 w-4" />
              Buscar en Google Maps sin usar mi ubicación
            </Button>
          )}

          {estado === "idle" && (
            <button
              className="text-xs text-muted-foreground underline underline-offset-2"
              onClick={abrirSinUbicacion}
              data-testid="button-sin-ubicacion-link"
            >
              Buscar sin compartir mi ubicación
            </button>
          )}
        </CardContent>
      </Card>

      {/* Error de geolocalización */}
      {estado === "error" && (
        <Alert className="border-orange-300 bg-orange-50 dark:bg-orange-950/30 dark:border-orange-800 animate-in fade-in">
          <AlertTriangle className="h-4 w-4 text-orange-600 dark:text-orange-400" />
          <AlertDescription className="text-sm text-orange-800 dark:text-orange-300">
            <p className="font-semibold mb-1">No se pudo obtener tu ubicación</p>
            <p>{errorMsg}</p>
            <Button
              variant="outline"
              size="sm"
              className="mt-3 gap-2 border-orange-400 text-orange-700 dark:text-orange-400"
              onClick={abrirSinUbicacion}
            >
              <ExternalLink className="h-3.5 w-3.5" />
              Abrir búsqueda general en Maps
            </Button>
          </AlertDescription>
        </Alert>
      )}

      {/* Confirmación */}
      {estado === "listo" && (
        <Alert className="border-green-300 bg-green-50 dark:bg-green-950/30 dark:border-green-800 animate-in fade-in">
          <MapPin className="h-4 w-4 text-green-600 dark:text-green-400" />
          <AlertDescription className="text-sm text-green-800 dark:text-green-300">
            Google Maps se abrió con los resultados cercanos a tu ubicación. Si no encontraste lo que buscabas, intenta buscar nuevamente.
          </AlertDescription>
        </Alert>
      )}

      {/* Info normativa */}
      <Card className="border-border/40 shadow-sm">
        <CardContent className="p-4 space-y-3">
          <div className="flex items-center gap-2">
            <Info className="h-4 w-4 text-primary shrink-0" />
            <h3 className="font-semibold text-sm">¿Qué es un CEA?</h3>
          </div>
          <p className="text-xs text-muted-foreground leading-relaxed">
            Los <strong>Centros de Enseñanza Automovilística (CEA)</strong> son instituciones habilitadas por el Ministerio de Transporte de Colombia para impartir la formación teórico-práctica requerida para obtener o recategorizar una licencia de conducción.
          </p>
          <div className="bg-muted/40 rounded-lg p-3 space-y-1">
            <p className="text-xs font-semibold">Antes de matricularte verifica en el RUNT:</p>
            <ul className="text-xs text-muted-foreground space-y-0.5 list-disc pl-4">
              <li>Que el CEA esté habilitado y vigente</li>
              <li>Que ofrezca la categoría de licencia que necesitas</li>
              <li>Que cuente con pistas de práctica certificadas</li>
            </ul>
          </div>
          <Button
            variant="outline"
            size="sm"
            className="w-full gap-2 text-xs"
            onClick={() => window.open("https://www.runt.com.co", "_blank")}
            data-testid="button-runt"
          >
            <ExternalLink className="h-3.5 w-3.5 text-accent" />
            Consultar habilitación en RUNT
          </Button>
        </CardContent>
      </Card>

      <p className="text-center text-xs text-muted-foreground px-4">
        Cepheus Transit no está afiliado a ningún CEA. La información de ubicación se usa únicamente para realizar la búsqueda en Google Maps y no es almacenada.
      </p>
    </div>
  );
}
