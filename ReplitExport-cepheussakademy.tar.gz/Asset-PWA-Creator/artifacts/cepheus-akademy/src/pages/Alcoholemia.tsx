import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { format, differenceInMinutes, parse } from "date-fns";
import {
  Scale, AlertTriangle, CheckCircle2, XCircle, Info,
  Calculator, Clock, FlaskConical, ShieldCheck, ShieldX, Printer
} from "lucide-react";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";

/*
 * Marco normativo:
 *   Ley 1696 de 2013 — grados y sanciones
 *   Ley 769 de 2002  — Código Nacional de Tránsito
 *   Resolución 1844 de 2015 — INMLCF (protocolo técnico vigente)
 *   OIML R 126       — estándares internacionales del alcohosensor
 *
 * Unidad: mg de etanol / 100 mL de sangre equivalente (BAC)
 * Factor de corrección por incertidumbre del equipo: 0.925 (Res. 1844)
 * Valor final: Math.floor(promedio × 0.925) — truncar, no redondear (in dubio pro reo)
 */

const FACTOR_CORRECCION = 0.925;

/* ── Grados según Ley 1696/2013 ── */
type Grado = "NEGATIVO" | "GRADO CERO" | "GRADO UNO" | "GRADO DOS" | "GRADO TRES";

const GRADOS: Array<{
  id: Grado; min: number; max: number; color: string;
  sancionTexto: string; smldv: number; suspension: string; otro: string;
  sintomas: string;
}> = [
  {
    id: "NEGATIVO",   min: 0,   max: 19,
    color: "green",
    sancionTexto: "Sin sanción de tránsito",
    smldv: 0, suspension: "Ninguna", otro: "",
    sintomas: "Sin manifestaciones clínicas atribuibles al alcohol.",
  },
  {
    id: "GRADO CERO", min: 20,  max: 39,
    color: "yellow",
    sancionTexto: "30 SMLDV · Curso obligatorio",
    smldv: 30, suspension: "Ninguna", otro: "Curso obligatorio de tránsito",
    sintomas: "Nistagmos posrotacional discreto, incoordinación motora leve, aliento alcohólico.",
  },
  {
    id: "GRADO UNO",  min: 40,  max: 99,
    color: "orange",
    sancionTexto: "60 SMLDV · Suspensión 1 año · Retención vehículo",
    smldv: 60, suspension: "365 días", otro: "Retención del vehículo",
    sintomas: "Nistagmos posrotacional evidente, incoordinación moderada, aliento alcohólico, disartria.",
  },
  {
    id: "GRADO DOS",  min: 100, max: 149,
    color: "red",
    sancionTexto: "120 SMLDV · Suspensión 2 años · Retención vehículo",
    smldv: 120, suspension: "730 días", otro: "Retención del vehículo",
    sintomas: "Nistagmos espontáneo, disartria, alteración en convergencia ocular, incoordinación severa.",
  },
  {
    id: "GRADO TRES", min: 150, max: 9999,
    color: "darkred",
    sancionTexto: "360 SMLDV · Cancelación definitiva · Proceso penal",
    smldv: 360, suspension: "Cancelación definitiva", otro: "Proceso penal",
    sintomas: "Imposibilidad de articular lenguaje, amnesia lacunar, incapacidad de mantener postura, estupor.",
  },
];

function determinarGrado(vrFinal: number): typeof GRADOS[0] {
  return GRADOS.find(g => vrFinal >= g.min && vrFinal <= g.max) ?? GRADOS[0];
}

/* ── Tolerancia del par según rango (Res. 1844/2015, num. 7.3.2.8) ── */
function toleranciaPar(mayor: number): number {
  if (mayor >= 20  && mayor <= 39)  return 5;
  if (mayor >= 40  && mayor <= 99)  return 10;
  if (mayor >= 100 && mayor <= 149) return 15;
  if (mayor >= 150)                  return 20;
  return 0;
}

function validarPar(m1: number, m2: number): { valido: boolean; diferencia: number; tolerancia: number } {
  const diferencia = Math.abs(m1 - m2);
  const mayor = Math.max(m1, m2);
  const tolerancia = toleranciaPar(mayor);
  return { valido: diferencia <= tolerancia, diferencia, tolerancia };
}

/* ── Zod schema ── */
const formSchema = z.object({
  // Pre-analítica
  operador:              z.string().min(3, "Obligatorio"),
  equipo:                z.string().min(2, "Obligatorio"),
  fechaCalibracion:      z.string().min(1, "Obligatorio"),
  fechaVencimientoCert:  z.string().min(1, "Obligatorio"),
  ingestionReciente:     z.boolean(),
  vomitoReciente:        z.boolean(),
  enjuagueReciente:      z.boolean(),
  // Blanco
  horaBlanco:            z.string().regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/, "HH:MM"),
  resultadoBlanco:       z.coerce.number().min(0).max(10),
  // Muestras
  horaPrimera:           z.string().regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/, "HH:MM"),
  resPrimera:            z.coerce.number().min(0, "≥ 0").max(300, "≤ 300"),
  boquillaPrimera:       z.boolean(),
  horaSegunda:           z.string().optional(),
  resSegunda:            z.coerce.number().min(0).max(300).optional(),
  boquillaSegunda:       z.boolean(),
});

type FormValues = z.infer<typeof formSchema>;

type ResultadoFinal = {
  valida: boolean;
  errores: string[];
  advertencias: string[];
  valorFinal: number | null;
  vrPrueba: number | null;
  promedioBruto: number | null;
  grado: typeof GRADOS[0] | null;
  intervaloMin: number | null;
  parValido: boolean | null;
  diferencia: number | null;
  toleranciaAplicada: number | null;
  esNegativo: boolean;
};

/* ── Colores por grado ── */
const gradoTextClass: Record<string, string> = {
  green:   "text-green-700 dark:text-green-400",
  yellow:  "text-yellow-700 dark:text-yellow-400",
  orange:  "text-orange-600 dark:text-orange-400",
  red:     "text-destructive",
  darkred: "text-red-900 dark:text-red-400",
};
const gradoBorderBg: Record<string, string> = {
  green:   "border-green-400 bg-green-50 dark:bg-green-950/30",
  yellow:  "border-yellow-400 bg-yellow-50 dark:bg-yellow-950/30",
  orange:  "border-orange-400 bg-orange-50 dark:bg-orange-950/30",
  red:     "border-destructive bg-destructive/10",
  darkred: "border-red-900 bg-red-950/20 dark:bg-red-950/40",
};

function Badge_Valida({ ok, label }: { ok: boolean; label: string }) {
  return (
    <span className={`inline-flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full
      ${ok ? "bg-green-100 text-green-800 dark:bg-green-950/50 dark:text-green-400"
           : "bg-destructive/10 text-destructive"}`}>
      {ok ? <CheckCircle2 className="h-3 w-3" /> : <XCircle className="h-3 w-3" />}
      {label}
    </span>
  );
}

export default function Alcoholemia() {
  const [resultado, setResultado] = useState<ResultadoFinal | null>(null);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      operador: "", equipo: "", fechaCalibracion: "", fechaVencimientoCert: "",
      ingestionReciente: false, vomitoReciente: false, enjuagueReciente: false,
      horaBlanco: "", resultadoBlanco: 0,
      horaPrimera: "", resPrimera: 0, boquillaPrimera: false,
      horaSegunda: "", resSegunda: undefined, boquillaSegunda: false,
    },
  });

  const onSubmit = (data: FormValues) => {
    const hoy = new Date();
    const dateStr = format(hoy, "yyyy-MM-dd");
    const res: ResultadoFinal = {
      valida: false, errores: [], advertencias: [],
      valorFinal: null, vrPrueba: null, promedioBruto: null,
      grado: null, intervaloMin: null, parValido: null,
      diferencia: null, toleranciaAplicada: null, esNegativo: false,
    };

    /* ── 1. PRE-ANALÍTICA: Calibración del equipo (máx 6 meses) ── */
    const fechaCalib = new Date(data.fechaCalibracion);
    const mesesCalib = (hoy.getTime() - fechaCalib.getTime()) / (1000 * 60 * 60 * 24 * 30);
    if (mesesCalib > 6) {
      res.errores.push(`EQUIPO: Calibración vencida (${Math.floor(mesesCalib)} meses). El máximo permitido es 6 meses (Res. 1844/2015, Anexo 1.7). Prueba inválida — causal de nulidad.`);
    }

    /* ── 2. PRE-ANALÍTICA: Certificación del operador (máx 5 años) ── */
    const fechaVencCert = new Date(data.fechaVencimientoCert);
    if (hoy > fechaVencCert) {
      res.errores.push(`OPERADOR: Certificación vencida (venció ${format(fechaVencCert, "dd/MM/yyyy")}). Prueba inválida — causal de nulidad (Res. 1844/2015, Parágrafo 1).`);
    }

    /* ── 3. PRE-ANALÍTICA: Condiciones del examinado ── */
    if (data.ingestionReciente || data.vomitoReciente || data.enjuagueReciente) {
      const causas = [
        data.ingestionReciente && "ingesta reciente de alcohol",
        data.vomitoReciente && "vómito reciente",
        data.enjuagueReciente && "uso reciente de enjuague bucal",
      ].filter(Boolean).join(", ");
      res.advertencias.push(`PRE-ANALÍTICA: El examinado manifiesta ${causas}. Se deben esperar mínimo 15 minutos antes de tomar la muestra (Res. 1844/2015, Fase Pre-analítica).`);
    }

    /* ── 4. PRUEBA EN BLANCO ── */
    if (data.resultadoBlanco !== 0) {
      res.errores.push(`BLANCO: El resultado de la prueba en blanco es ${data.resultadoBlanco} mg (debe ser 0). El equipo presenta contaminación. Prueba inválida — no continuar.`);
      setResultado(res);
      return;
    }

    /* ── 5. Boquillas ── */
    if (!data.boquillaPrimera) {
      res.advertencias.push("1ra MUESTRA: No se confirmó el uso de boquilla nueva y sellada (Res. 1844/2015, Fase Analítica).");
    }

    /* ── 6. PRIMERA MUESTRA ── */
    const m1 = data.resPrimera;

    // Si M1 < 20: NEGATIVO, no se requiere segunda muestra
    if (m1 < 20) {
      res.esNegativo = true;
      res.valorFinal = 0;
      res.vrPrueba = m1 * FACTOR_CORRECCION;
      res.promedioBruto = m1;
      res.grado = GRADOS[0]; // NEGATIVO
      res.valida = res.errores.length === 0;
      res.advertencias.push("Resultado de la primera muestra < 20 mg. Se clasifica como NEGATIVO. No se requiere segunda muestra según Res. 1844/2015.");
      setResultado(res);
      return;
    }

    /* ── 7. SEGUNDA MUESTRA (obligatoria si M1 ≥ 20) ── */
    if (!data.horaSegunda || data.resSegunda === undefined || data.resSegunda === null) {
      res.errores.push("SEGUNDA MUESTRA: La primera muestra es ≥ 20 mg, por lo que la segunda medición es obligatoria (Res. 1844/2015, Fase Analítica, Paso 3).");
      setResultado(res);
      return;
    }

    if (!data.boquillaSegunda) {
      res.advertencias.push("2da MUESTRA: No se confirmó el uso de boquilla nueva y sellada (Res. 1844/2015, Fase Analítica).");
    }

    const m2 = data.resSegunda;

    /* ── 8. INTERVALO M1 → M2 (debe ser 2–10 min) ── */
    const tPrimera = parse(`${dateStr} ${data.horaPrimera}`, "yyyy-MM-dd HH:mm", new Date());
    const tSegunda = parse(`${dateStr} ${data.horaSegunda}`, "yyyy-MM-dd HH:mm", new Date());
    const intervaloMin = differenceInMinutes(tSegunda, tPrimera);
    res.intervaloMin = intervaloMin;

    if (intervaloMin < 0) {
      res.errores.push("INTERVALO: La segunda muestra no puede ser anterior a la primera.");
    } else if (intervaloMin < 2) {
      res.errores.push(`INTERVALO: ${intervaloMin} min entre muestras. El mínimo es 2 minutos (Res. 1844/2015, num. 7.3.2.8). Par INVÁLIDO — repetir ciclo completo.`);
    } else if (intervaloMin > 10) {
      res.errores.push(`INTERVALO: ${intervaloMin} min entre muestras. El máximo es 10 minutos (Res. 1844/2015, num. 7.3.2.8). Par INVÁLIDO — repetir ciclo completo.`);
    }

    /* ── 9. VALIDACIÓN DEL PAR DE MEDICIONES (tolerancia por rango) ── */
    const { valido: parValido, diferencia, tolerancia } = validarPar(m1, m2);
    res.parValido = parValido;
    res.diferencia = diferencia;
    res.toleranciaAplicada = tolerancia;

    if (!parValido) {
      res.errores.push(
        `PAR INVÁLIDO: Diferencia entre M1 (${m1} mg) y M2 (${m2} mg) = ${diferencia} mg. Para este rango la tolerancia máxima es ${tolerancia} mg (Res. 1844/2015, tabla de parejas válidas). Repetir ciclo completo.`
      );
    }

    /* ── 10. CÁLCULO DEL VALOR FINAL ── */
    const promedioBruto = (m1 + m2) / 2;
    const vrPrueba = promedioBruto * FACTOR_CORRECCION;
    const vrFinal = Math.floor(vrPrueba); // truncar, nunca redondear

    res.promedioBruto = promedioBruto;
    res.vrPrueba = vrPrueba;
    res.valorFinal = vrFinal;
    res.grado = determinarGrado(vrFinal);
    res.valida = res.errores.length === 0;

    setResultado(res);
    setTimeout(() => window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" }), 100);
  };

  const hayError = resultado && resultado.errores.length > 0;
  const hayAdvertencia = resultado && resultado.advertencias.length > 0 && resultado.errores.length === 0;

  return (
    <div className="flex flex-col h-full p-4 pb-24 animate-in fade-in gap-5">

      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2 mb-1">
          <Scale className="h-6 w-6 text-accent" /> Validador de Alcoholemia
        </h1>
        <p className="text-muted-foreground text-sm leading-relaxed">
          Implementa el protocolo completo de la <strong>Resolución 1844 de 2015 — INMLCF</strong> y la escala de la <strong>Ley 1696 de 2013</strong>. Uso académico y didáctico.
        </p>
      </div>

      <Alert className="bg-primary/5 border-primary/20">
        <Info className="h-4 w-4 text-primary" />
        <AlertTitle className="text-primary font-bold text-sm">Aviso Legal</AlertTitle>
        <AlertDescription className="text-xs leading-relaxed">
          Esta herramienta no reemplaza el análisis jurídico de un abogado ni la valoración de la autoridad competente. El resultado legal válido solo lo emite el equipo alcohosensor certificado operado por personal autorizado.
        </AlertDescription>
      </Alert>

      {/* Tabla de grados */}
      <Card className="border-border/40 shadow-sm">
        <CardHeader className="pb-3 bg-muted/30">
          <CardTitle className="text-sm flex items-center gap-2">
            <FlaskConical className="h-4 w-4 text-accent" /> Escala Oficial — Ley 1696 de 2013
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0 overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border/50 bg-muted/20 text-left">
                <th className="p-2.5 font-semibold">Grado</th>
                <th className="p-2.5 font-semibold">mg%</th>
                <th className="p-2.5 font-semibold">Sanción</th>
              </tr>
            </thead>
            <tbody>
              {GRADOS.map((g, i) => (
                <tr key={g.id} className={i < GRADOS.length - 1 ? "border-b border-border/30" : ""}>
                  <td className={`p-2.5 font-bold ${gradoTextClass[g.color]}`}>{g.id}</td>
                  <td className="p-2.5 text-muted-foreground">{g.min === 0 ? "0 – 19" : g.max === 9999 ? `≥ ${g.min}` : `${g.min} – ${g.max}`}</td>
                  <td className="p-2.5 text-muted-foreground leading-tight">{g.sancionTexto}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>

      {/* Formulario */}
      <Card className="border-border/50 shadow-sm">
        <CardHeader className="bg-muted/30 pb-4">
          <CardTitle className="text-lg flex items-center gap-2">
            <Calculator className="h-5 w-5" /> Datos del Procedimiento
          </CardTitle>
          <CardDescription>
            Ingrese los datos tal como aparecen en la tirilla impresa del alcohosensor.
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">

              {/* ── FASE PRE-ANALÍTICA ── */}
              <div className="space-y-4">
                <h3 className="font-bold text-xs uppercase tracking-wider text-accent flex items-center gap-2">
                  <ShieldCheck className="h-3.5 w-3.5" /> Fase Pre-Analítica
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField control={form.control} name="operador" render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs">Nombre del Operador</FormLabel>
                      <FormControl><Input placeholder="Nombre completo" {...field} /></FormControl>
                      <FormMessage className="text-xs" />
                    </FormItem>
                  )} />
                  <FormField control={form.control} name="equipo" render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs">Serial del Alcohosensor</FormLabel>
                      <FormControl><Input placeholder="Ej: ARX-1234" {...field} /></FormControl>
                      <FormMessage className="text-xs" />
                    </FormItem>
                  )} />
                  <FormField control={form.control} name="fechaCalibracion" render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs">Fecha Último Mantenimiento/Calibración</FormLabel>
                      <FormControl><Input type="date" {...field} /></FormControl>
                      <FormMessage className="text-xs" />
                      <p className="text-[10px] text-muted-foreground">Máx. 6 meses de vigencia (Res. 1844/2015)</p>
                    </FormItem>
                  )} />
                  <FormField control={form.control} name="fechaVencimientoCert" render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs">Vencimiento Certificación Operador</FormLabel>
                      <FormControl><Input type="date" {...field} /></FormControl>
                      <FormMessage className="text-xs" />
                      <p className="text-[10px] text-muted-foreground">Validez 5 años (obligatoria desde 2017)</p>
                    </FormItem>
                  )} />
                </div>

                <div className="bg-muted/40 rounded-xl p-4 space-y-3">
                  <p className="text-xs font-semibold text-muted-foreground">El examinado manifiesta (esperar 15 min si alguna aplica):</p>
                  {[
                    { name: "ingestionReciente" as const, label: "Ingesta reciente de alcohol" },
                    { name: "vomitoReciente"    as const, label: "Vómito reciente" },
                    { name: "enjuagueReciente"  as const, label: "Uso reciente de enjuague bucal" },
                  ].map(({ name, label }) => (
                    <FormField key={name} control={form.control} name={name} render={({ field }) => (
                      <FormItem className="flex items-center gap-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={!!field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <FormLabel className="text-xs font-normal cursor-pointer">{label}</FormLabel>
                      </FormItem>
                    )} />
                  ))}
                </div>
              </div>

              <Separator />

              {/* ── PRUEBA EN BLANCO ── */}
              <div className="space-y-3">
                <h3 className="font-bold text-xs uppercase tracking-wider text-accent flex items-center gap-2">
                  <Clock className="h-3.5 w-3.5" /> Prueba en Blanco (Aire Ambiente)
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  <FormField control={form.control} name="horaBlanco" render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs">Hora Prueba Blanco (HH:MM)</FormLabel>
                      <FormControl><Input placeholder="22:10" {...field} /></FormControl>
                      <FormMessage className="text-xs" />
                    </FormItem>
                  )} />
                  <FormField control={form.control} name="resultadoBlanco" render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs">Resultado Blanco (mg%)</FormLabel>
                      <FormControl><Input type="number" step="1" min="0" max="10" placeholder="Debe ser 0" {...field} /></FormControl>
                      <FormMessage className="text-xs" />
                    </FormItem>
                  )} />
                </div>
                <p className="text-[10px] text-muted-foreground bg-muted/40 rounded-lg px-3 py-2">
                  El resultado del blanco debe ser <strong>0 mg</strong>. Si es distinto, el equipo está contaminado y la prueba es inválida.
                </p>
              </div>

              <Separator />

              {/* ── PRIMERA MUESTRA ── */}
              <div className="space-y-3">
                <h3 className="font-bold text-xs uppercase tracking-wider text-accent flex items-center gap-2">
                  <FlaskConical className="h-3.5 w-3.5" /> Primera Muestra
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  <FormField control={form.control} name="horaPrimera" render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs">Hora 1ra Muestra (HH:MM)</FormLabel>
                      <FormControl><Input placeholder="22:13" {...field} /></FormControl>
                      <FormMessage className="text-xs" />
                    </FormItem>
                  )} />
                  <FormField control={form.control} name="resPrimera" render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs">Resultado 1ra Muestra (mg%)</FormLabel>
                      <FormControl><Input type="number" step="1" min="0" max="300" placeholder="Ej: 45" {...field} /></FormControl>
                      <FormMessage className="text-xs" />
                    </FormItem>
                  )} />
                </div>
                <FormField control={form.control} name="boquillaPrimera" render={({ field }) => (
                  <FormItem className="flex items-center gap-3 space-y-0 bg-muted/40 rounded-lg p-3">
                    <FormControl>
                      <Checkbox checked={!!field.value} onCheckedChange={field.onChange} />
                    </FormControl>
                    <FormLabel className="text-xs font-normal cursor-pointer">
                      Confirmo que se usó boquilla nueva y sellada para la 1ra muestra
                    </FormLabel>
                  </FormItem>
                )} />
              </div>

              <Separator />

              {/* ── SEGUNDA MUESTRA ── */}
              <div className="space-y-3">
                <h3 className="font-bold text-xs uppercase tracking-wider text-accent flex items-center gap-2">
                  <FlaskConical className="h-3.5 w-3.5" /> Segunda Muestra
                  <span className="text-muted-foreground font-normal normal-case text-[10px]">(obligatoria si 1ra ≥ 20 mg)</span>
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  <FormField control={form.control} name="horaSegunda" render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs">Hora 2da Muestra (HH:MM)</FormLabel>
                      <FormControl><Input placeholder="22:20" {...field} /></FormControl>
                      <FormMessage className="text-xs" />
                    </FormItem>
                  )} />
                  <FormField control={form.control} name="resSegunda" render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs">Resultado 2da Muestra (mg%)</FormLabel>
                      <FormControl><Input type="number" step="1" min="0" max="300" placeholder="Ej: 43" {...field} /></FormControl>
                      <FormMessage className="text-xs" />
                    </FormItem>
                  )} />
                </div>
                <FormField control={form.control} name="boquillaSegunda" render={({ field }) => (
                  <FormItem className="flex items-center gap-3 space-y-0 bg-muted/40 rounded-lg p-3">
                    <FormControl>
                      <Checkbox checked={!!field.value} onCheckedChange={field.onChange} />
                    </FormControl>
                    <FormLabel className="text-xs font-normal cursor-pointer">
                      Confirmo que se usó boquilla nueva y sellada para la 2da muestra
                    </FormLabel>
                  </FormItem>
                )} />
                <p className="text-[10px] text-muted-foreground bg-muted/40 rounded-lg px-3 py-2">
                  Intervalo entre muestras: <strong>mínimo 2 min — máximo 10 min</strong> (Res. 1844/2015, num. 7.3.2.8).
                </p>
              </div>

              <Button type="submit" className="w-full bg-accent hover:bg-accent/90 text-white font-bold h-12 text-base">
                Validar Procedimiento
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>

      {/* ── RESULTADO ── */}
      {resultado && (
        <div className="space-y-4 animate-in zoom-in-95 duration-300">

          {/* Veredicto principal */}
          <Card className={`border-2 ${
            resultado.valida
              ? "border-green-500 bg-green-50 dark:bg-green-950/30"
              : hayAdvertencia
                ? "border-orange-400 bg-orange-50 dark:bg-orange-950/30"
                : "border-destructive bg-destructive/10"
          }`}>
            <CardHeader className="pb-3">
              <CardTitle className={`flex items-center gap-2 text-base ${
                resultado.valida ? "text-green-700 dark:text-green-400"
                : hayAdvertencia ? "text-orange-700 dark:text-orange-400"
                : "text-destructive"
              }`}>
                {resultado.valida
                  ? <ShieldCheck className="h-5 w-5" />
                  : hayAdvertencia
                    ? <AlertTriangle className="h-5 w-5" />
                    : <ShieldX className="h-5 w-5" />}
                {resultado.valida
                  ? "PRUEBA VÁLIDA"
                  : hayAdvertencia
                    ? "PRUEBA VÁLIDA CON ADVERTENCIAS"
                    : "PRUEBA INVÁLIDA"}
              </CardTitle>
            </CardHeader>
            {(resultado.errores.length > 0 || resultado.advertencias.length > 0) && (
              <CardContent>
                {resultado.errores.map((e, i) => (
                  <div key={i} className="flex gap-2 mb-2">
                    <XCircle className="h-4 w-4 text-destructive shrink-0 mt-0.5" />
                    <p className="text-sm leading-relaxed">{e}</p>
                  </div>
                ))}
                {resultado.advertencias.map((a, i) => (
                  <div key={i} className="flex gap-2 mb-2">
                    <AlertTriangle className="h-4 w-4 text-orange-500 shrink-0 mt-0.5" />
                    <p className="text-sm leading-relaxed">{a}</p>
                  </div>
                ))}
              </CardContent>
            )}
          </Card>

          {/* Tabla de verificación (columnas Res. 1844) */}
          {resultado.valorFinal !== null && resultado.grado && (
            <>
              <Card className="border-border/50 shadow-sm">
                <CardHeader className="pb-3 bg-muted/30">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Printer className="h-4 w-4" /> Tabla de Verificación — Res. 1844/2015
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <table className="w-full text-xs">
                    <tbody>
                      {[
                        ["Resultado blanco", `${form.getValues("resultadoBlanco")} mg`,
                          <Badge_Valida ok={form.getValues("resultadoBlanco") === 0} label={form.getValues("resultadoBlanco") === 0 ? "CUMPLE" : "NO CUMPLE"} />],
                        ["1ra Muestra (M1)", `${form.getValues("resPrimera")} mg%`, null],
                        !resultado.esNegativo && ["2da Muestra (M2)", `${form.getValues("resSegunda")} mg%`, null],
                        !resultado.esNegativo && resultado.intervaloMin !== null && [
                          "Intervalo M1→M2",
                          `${resultado.intervaloMin} min`,
                          <Badge_Valida ok={resultado.intervaloMin >= 2 && resultado.intervaloMin <= 10} label={resultado.intervaloMin >= 2 && resultado.intervaloMin <= 10 ? "VÁLIDO (2-10 min)" : "INVÁLIDO"} />
                        ],
                        !resultado.esNegativo && resultado.diferencia !== null && [
                          "Diferencia M1-M2",
                          `${resultado.diferencia} mg (tol. ≤ ${resultado.toleranciaAplicada} mg)`,
                          <Badge_Valida ok={!!resultado.parValido} label={resultado.parValido ? "PAR VÁLIDO" : "PAR INVÁLIDO"} />
                        ],
                        !resultado.esNegativo && resultado.promedioBruto !== null && [
                          "Promedio bruto",
                          `${resultado.promedioBruto.toFixed(2)} mg%`,
                          null
                        ],
                        !resultado.esNegativo && resultado.vrPrueba !== null && [
                          "Vr. Prueba (× 0.925)",
                          `${resultado.vrPrueba.toFixed(4)} mg%`,
                          null
                        ],
                        [
                          "Valor Final (truncado)",
                          <span className="font-bold text-base">{resultado.valorFinal} mg%</span>,
                          null
                        ],
                      ].filter(Boolean).map((row, i) => row && (
                        <tr key={i} className="border-b border-border/30 last:border-0">
                          <td className="p-3 text-muted-foreground font-medium w-2/5">{row[0] as string}</td>
                          <td className="p-3 font-semibold">{row[1] as React.ReactNode}</td>
                          <td className="p-3">{row[2] as React.ReactNode}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </CardContent>
              </Card>

              {/* Grado determinado */}
              <Card className={`border-2 ${gradoBorderBg[resultado.grado.color]}`}>
                <CardContent className="p-5">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <p className="text-xs text-muted-foreground font-medium mb-1">Grado determinado (Ley 1696/2013)</p>
                      <p className={`text-3xl font-black tracking-tight ${gradoTextClass[resultado.grado.color]}`}>
                        {resultado.grado.id}
                      </p>
                      <p className="text-sm font-semibold mt-2">{resultado.grado.sancionTexto}</p>
                      {resultado.grado.otro && (
                        <Badge variant="outline" className="mt-2 text-xs">{resultado.grado.otro}</Badge>
                      )}
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-muted-foreground">Valor final</p>
                      <p className={`text-4xl font-black ${gradoTextClass[resultado.grado.color]}`}>{resultado.valorFinal}</p>
                      <p className="text-xs text-muted-foreground">mg%</p>
                    </div>
                  </div>
                  {resultado.grado.sintomas && (
                    <div className="mt-4 pt-4 border-t border-border/40">
                      <p className="text-xs font-semibold text-muted-foreground mb-1">Referencia clínica (evaluación médico legista):</p>
                      <p className="text-xs text-muted-foreground leading-relaxed">{resultado.grado.sintomas}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </>
          )}

          <div className="bg-primary/5 p-4 rounded-xl flex gap-3 text-xs text-muted-foreground items-start">
            <Info className="h-4 w-4 text-primary shrink-0 mt-0.5" />
            <p>
              Uso exclusivamente <strong>académico y didáctico</strong>. Marco normativo: <strong>Ley 1696/2013</strong> · <strong>Ley 769/2002</strong> · <strong>Res. 1844 de 2015 — INMLCF</strong> · <strong>OIML R 126</strong>.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
