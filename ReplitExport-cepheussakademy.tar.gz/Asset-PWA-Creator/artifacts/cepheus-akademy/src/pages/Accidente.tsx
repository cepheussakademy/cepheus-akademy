import { useState, useEffect } from "react";
import { CheckCircle2, Phone, Camera, Users, ShieldAlert, FileText, Save, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Progress } from "@/components/ui/progress";

const STEPS = [
  {
    id: "heridos",
    title: "¿Hay heridos?",
    description: "Si hay lesionados, llama inmediatamente a emergencias 123. Solicitando la presencia de la Autoridad de Tránsito.",
    icon: Phone,
    action: () => window.location.href = "tel:123",
    actionLabel: "Llamar 123",
    urgent: true
  },
  {
    id: "mover",
    title: "No mover vehículos",
    description: "Si hay lesionados o fallecidos, está prohibido mover los vehículos hasta que llegue la autoridad. Si son solo daños materiales, toma fotos y muévelos.",
    icon: ShieldAlert,
  },
  {
    id: "fotos",
    title: "Documentar el lugar",
    description: "Toma fotografías panorámicas, daños de los vehículos, señales de tránsito cercanas y placas.",
    icon: Camera,
  },
  {
    id: "testigos",
    title: "Datos de testigos",
    description: "Busca personas que hayan presenciado el hecho y anota su nombre y teléfono.",
    icon: Users,
    hasInput: true,
    inputPlaceholder: "Nombres y teléfonos de testigos..."
  },
  {
    id: "seguro",
    title: "Reportar a la aseguradora",
    description: "Llama a tu compañía de seguros (y SOAT si hay heridos) desde el lugar de los hechos.",
    icon: Phone,
  },
  {
    id: "notas",
    title: "Notas adicionales",
    description: "Anota cualquier detalle relevante: clima, estado de la vía, versión del otro conductor.",
    icon: FileText,
    hasInput: true,
    inputPlaceholder: "El piso estaba mojado, el otro vehículo se pasó el semáforo..."
  }
];

export default function Accidente() {
  const [completedSteps, setCompletedSteps] = useState<Record<string, boolean>>({});
  const [notes, setNotas] = useState<Record<string, string>>({});
  const { toast } = useToast();

  useEffect(() => {
    const savedCompleted = localStorage.getItem("accidente_completed");
    const savedNotes = localStorage.getItem("accidente_notes");
    
    if (savedCompleted) setCompletedSteps(JSON.parse(savedCompleted));
    if (savedNotes) setNotas(JSON.parse(savedNotes));
  }, []);

  const toggleStep = (id: string) => {
    const next = { ...completedSteps, [id]: !completedSteps[id] };
    setCompletedSteps(next);
    localStorage.setItem("accidente_completed", JSON.stringify(next));
  };

  const handleNoteChange = (id: string, value: string) => {
    setNotas(prev => ({ ...prev, [id]: value }));
  };

  const saveNotes = () => {
    localStorage.setItem("accidente_notes", JSON.stringify(notes));
    toast({
      title: "Guardado exitoso",
      description: "Tus notas han sido guardadas en este dispositivo.",
    });
  };

  const completedCount = Object.values(completedSteps).filter(Boolean).length;
  const progress = (completedCount / STEPS.length) * 100;

  return (
    <div className="flex flex-col min-h-full pb-24 animate-in fade-in">
      <div className="bg-destructive text-destructive-foreground p-6 pt-8 pb-8 rounded-b-[2rem] shadow-md">
        <h1 className="text-2xl font-bold tracking-tight mb-2">Protocolo de Accidente</h1>
        <p className="text-destructive-foreground/90 font-medium text-sm">
          Guía paso a paso para proteger tus derechos en caso de siniestro vial.
        </p>
      </div>

      <div className="px-4 -mt-4">
        <Card className="shadow-lg border-none">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="flex-1">
              <div className="flex justify-between mb-1">
                <span className="text-sm font-semibold">Progreso</span>
                <span className="text-sm font-bold text-accent">{completedCount} de {STEPS.length}</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
            {progress === 100 && (
              <CheckCircle2 className="h-8 w-8 text-green-500 animate-in zoom-in" />
            )}
          </CardContent>
        </Card>
      </div>

      <div className="p-4 space-y-4 mt-2">
        {STEPS.map((step) => {
          const Icon = step.icon;
          const isCompleted = completedSteps[step.id];

          return (
            <Card 
              key={step.id} 
              className={`border-l-4 transition-all duration-300 ${
                isCompleted 
                  ? "border-l-green-500 bg-green-50/50 dark:bg-green-950/20" 
                  : step.urgent 
                    ? "border-l-destructive shadow-md" 
                    : "border-l-primary/20 hover:border-l-primary/50"
              }`}
            >
              <CardContent className="p-0">
                <div className="p-4">
                  <div className="flex items-start gap-3">
                    <Checkbox 
                      id={`step-${step.id}`}
                      checked={!!isCompleted}
                      onCheckedChange={() => toggleStep(step.id)}
                      className={`mt-1 ${isCompleted ? "data-[state=checked]:bg-green-500 data-[state=checked]:text-white data-[state=checked]:border-green-500" : ""}`}
                    />
                    <div className="grid gap-1.5 flex-1">
                      <label 
                        htmlFor={`step-${step.id}`}
                        className={`font-semibold cursor-pointer ${isCompleted ? "text-muted-foreground line-through" : ""}`}
                      >
                        <div className="flex items-center gap-2">
                          <Icon className={`h-4 w-4 ${step.urgent && !isCompleted ? "text-destructive" : "text-primary"}`} />
                          {step.title}
                        </div>
                      </label>
                      <p className={`text-sm ${isCompleted ? "text-muted-foreground/70" : "text-muted-foreground"}`}>
                        {step.description}
                      </p>
                      
                      {step.action && !isCompleted && (
                        <div className="mt-2">
                          <Button variant={step.urgent ? "destructive" : "outline"} size="sm" onClick={step.action}>
                            {step.actionLabel}
                          </Button>
                        </div>
                      )}
                      
                      {step.hasInput && (
                        <div className="mt-3">
                          <Textarea 
                            placeholder={step.inputPlaceholder}
                            className="bg-background resize-none min-h-[80px]"
                            value={notes[step.id] || ""}
                            onChange={(e) => handleNoteChange(step.id, e.target.value)}
                          />
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
        
        <div className="pt-4 flex flex-col gap-4 pb-8">
          <Button onClick={saveNotes} className="w-full bg-accent hover:bg-accent/90 text-white" size="lg">
            <Save className="mr-2 h-5 w-5" /> Guardar Notas Localmente
          </Button>
          
          <div className="bg-primary/5 p-4 rounded-xl flex gap-3 text-sm text-muted-foreground items-start">
            <Info className="h-5 w-5 text-primary shrink-0" />
            <p>Los datos se guardan únicamente en el almacenamiento de este dispositivo por privacidad y seguridad.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
