import { useState, useEffect, useCallback } from "react";
import {
  FileCheck, AlertTriangle, CheckCircle, XCircle,
  CalendarDays, RotateCcw, Info, Bell, BellOff,
  BellRing, ChevronDown
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

// ─── Storage keys ─────────────────────────────────────────────────────────────
const STORAGE_KEY    = "cepheus_documentos";
const REMINDER_KEY   = "cepheus_recordatorios";

// ─── Types ────────────────────────────────────────────────────────────────────
type DocKey = "soat" | "rtm" | "licencia";

interface DocData { soat: string; rtm: string; licencia: string; }

interface ReminderSettings {
  enabled: boolean;
  advanceDays: number;
  lastNotified: Partial<Record<DocKey, string>>;
}

const DEFAULT_REMINDER: ReminderSettings = {
  enabled: false,
  advanceDays: 30,
  lastNotified: {},
};

// ─── Documento metadata ───────────────────────────────────────────────────────
const DOC_INFO: Record<DocKey, { label: string; desc: string; icon: string; norma: string }> = {
  soat:     { label: "SOAT",                    desc: "Seguro Obligatorio de Accidentes de Tránsito",  icon: "🛡️", norma: "Ley 769/2002 · Decreto 056/2015" },
  rtm:      { label: "Revisión Técnico-Mecánica", desc: "Certificado de revisión técnico-mecánica y gases", icon: "🔧", norma: "Ley 769/2002 · Res. 3768/2013"   },
  licencia: { label: "Licencia de Conducción",   desc: "Vigencia de la licencia según categoría",      icon: "🪪", norma: "Ley 769/2002 · Res. 1555/2005"   },
};

// ─── Helpers ──────────────────────────────────────────────────────────────────
function getDaysLeft(dateStr: string): number | null {
  if (!dateStr) return null;
  const expiry = new Date(dateStr);
  expiry.setHours(23, 59, 59, 999);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return Math.ceil((expiry.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
}

type Status = "vencido" | "critico" | "proximo" | "vigente";

function getStatus(days: number | null): Status {
  if (days === null) return "vigente";
  if (days < 0)   return "vencido";
  if (days <= 15) return "critico";
  if (days <= 60) return "proximo";
  return "vigente";
}

function daysLabel(days: number | null): string {
  if (days === null) return "Sin fecha registrada";
  if (days < 0)  return `Venció hace ${Math.abs(days)} día${Math.abs(days) !== 1 ? "s" : ""}`;
  if (days === 0) return "Vence hoy";
  return `Vence en ${days} día${days !== 1 ? "s" : ""}`;
}

const today = () => new Date().toISOString().slice(0, 10);

// ─── Status visual config ─────────────────────────────────────────────────────
const STATUS_CONFIG: Record<Status, { color: string; bg: string; border: string; icon: JSX.Element; label: string }> = {
  vencido: { color: "text-red-700 dark:text-red-400",    bg: "bg-red-50 dark:bg-red-950/40",    border: "border-red-300 dark:border-red-800",    icon: <XCircle className="h-5 w-5 text-red-600 dark:text-red-400" />,      label: "VENCIDO"    },
  critico: { color: "text-orange-700 dark:text-orange-400", bg: "bg-orange-50 dark:bg-orange-950/40", border: "border-orange-300 dark:border-orange-800", icon: <AlertTriangle className="h-5 w-5 text-orange-600 dark:text-orange-400" />, label: "CRÍTICO"    },
  proximo: { color: "text-amber-700 dark:text-amber-400", bg: "bg-amber-50 dark:bg-amber-950/40",  border: "border-amber-300 dark:border-amber-800",  icon: <AlertTriangle className="h-5 w-5 text-amber-500 dark:text-amber-400" />,  label: "POR VENCER" },
  vigente: { color: "text-green-700 dark:text-green-400", bg: "bg-green-50 dark:bg-green-950/40",  border: "border-green-300 dark:border-green-800",  icon: <CheckCircle className="h-5 w-5 text-green-600 dark:text-green-400" />,   label: "VIGENTE"    },
};

// ─── Notification logic ───────────────────────────────────────────────────────
function fireNotification(key: DocKey, days: number, label: string) {
  if (Notification.permission !== "granted") return;
  const body =
    days < 0
      ? `Tu ${label} venció hace ${Math.abs(days)} día${Math.abs(days) !== 1 ? "s" : ""}. Renuévalo para evitar comparendos.`
      : days === 0
      ? `Tu ${label} vence HOY. Renuévalo lo antes posible.`
      : `Tu ${label} vence en ${days} día${days !== 1 ? "s" : ""}. Recuerda renovarlo a tiempo.`;

  new Notification("⚠️ Cepheus Transit — Documento por vencer", {
    body,
    icon: "/favicon.ico",
    tag: `cepheus-doc-${key}`,
  });
}

// ─── Component ────────────────────────────────────────────────────────────────
export default function Documentos() {
  const [dates,    setDates]    = useState<DocData>({ soat: "", rtm: "", licencia: "" });
  const [reminder, setReminder] = useState<ReminderSettings>(DEFAULT_REMINDER);
  const [permission, setPermission] = useState<NotificationPermission>("default");
  const [saved,    setSaved]    = useState(false);
  const [testSent, setTestSent] = useState(false);

  // ── Load from localStorage ──────────────────────────────────────────────────
  useEffect(() => {
    const storedDates = localStorage.getItem(STORAGE_KEY);
    if (storedDates) { try { setDates(JSON.parse(storedDates)); } catch {} }

    const storedReminder = localStorage.getItem(REMINDER_KEY);
    if (storedReminder) { try { setReminder(JSON.parse(storedReminder)); } catch {} }

    if ("Notification" in window) setPermission(Notification.permission);
  }, []);

  // ── Fire notifications on mount if enabled ──────────────────────────────────
  const checkAndNotify = useCallback((d: DocData, r: ReminderSettings) => {
    if (!r.enabled || Notification.permission !== "granted") return;
    const todayStr = today();
    const updated = { ...r.lastNotified };
    let changed = false;

    (Object.keys(DOC_INFO) as DocKey[]).forEach(key => {
      if (!d[key]) return;
      const days = getDaysLeft(d[key])!;
      const shouldAlert = days <= r.advanceDays;
      const notifiedToday = updated[key] === todayStr;

      if (shouldAlert && !notifiedToday) {
        fireNotification(key, days, DOC_INFO[key].label);
        updated[key] = todayStr;
        changed = true;
      }
    });

    if (changed) {
      const next = { ...r, lastNotified: updated };
      setReminder(next);
      localStorage.setItem(REMINDER_KEY, JSON.stringify(next));
    }
  }, []);

  useEffect(() => {
    if (reminder.enabled) checkAndNotify(dates, reminder);
  }, []); // only on mount

  // ── Save ────────────────────────────────────────────────────────────────────
  const save = () => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(dates));
    localStorage.setItem(REMINDER_KEY, JSON.stringify(reminder));
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const reset = () => {
    const empty = { soat: "", rtm: "", licencia: "" };
    setDates(empty);
    localStorage.removeItem(STORAGE_KEY);
  };

  // ── Notification permission ─────────────────────────────────────────────────
  const requestPermission = async () => {
    if (!("Notification" in window)) return;
    const result = await Notification.requestPermission();
    setPermission(result);
    if (result === "granted") {
      const next = { ...reminder, enabled: true };
      setReminder(next);
      localStorage.setItem(REMINDER_KEY, JSON.stringify(next));
      checkAndNotify(dates, next);
    }
  };

  const toggleReminder = (on: boolean) => {
    const next = { ...reminder, enabled: on };
    setReminder(next);
    localStorage.setItem(REMINDER_KEY, JSON.stringify(next));
    if (on && permission === "granted") checkAndNotify(dates, next);
  };

  const changeAdvance = (val: string) => {
    const next = { ...reminder, advanceDays: parseInt(val) };
    setReminder(next);
    localStorage.setItem(REMINDER_KEY, JSON.stringify(next));
  };

  const sendTestNotification = () => {
    if (Notification.permission !== "granted") return;
    new Notification("🔔 Cepheus Transit — Recordatorio activo", {
      body: "Los recordatorios de vencimiento de documentos están funcionando correctamente.",
      icon: "/favicon.ico",
      tag: "cepheus-test",
    });
    setTestSent(true);
    setTimeout(() => setTestSent(false), 3000);
  };

  const keys: DocKey[] = ["soat", "rtm", "licencia"];
  const alertCount = keys.filter(k => {
    const d = getDaysLeft(dates[k]);
    const s = getStatus(d);
    return s === "vencido" || s === "critico";
  }).length;

  const notifSupported = "Notification" in window;

  return (
    <div className="flex flex-col h-full animate-in fade-in p-4 pb-24 gap-5">

      {/* Header */}
      <div className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground p-6 rounded-2xl shadow-xl shadow-primary/20">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-accent/20 p-2 rounded-xl">
              <FileCheck className="h-8 w-8 text-accent" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Vigencia de Documentos</h1>
              <p className="text-primary-foreground/75 text-sm">SOAT · RTM · Licencia</p>
            </div>
          </div>
          <div className="flex flex-col items-end gap-1">
            {alertCount > 0 && (
              <div className="bg-red-500 text-white text-xs font-bold rounded-full h-7 w-7 flex items-center justify-center shadow">
                {alertCount}
              </div>
            )}
            {reminder.enabled && permission === "granted" && (
              <BellRing className="h-4 w-4 text-accent" />
            )}
          </div>
        </div>
      </div>

      {/* Tarjetas de documentos */}
      {keys.map((key) => {
        const info   = DOC_INFO[key];
        const days   = getDaysLeft(dates[key]);
        const status = dates[key] ? getStatus(days) : "vigente";
        const cfg    = STATUS_CONFIG[status];
        const hasDate = Boolean(dates[key]);

        return (
          <Card key={key} className={`border-2 overflow-hidden shadow-md ${hasDate ? cfg.border : "border-border/40"}`}>
            <CardContent className="p-4 space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-2">
                  <span className="text-2xl">{info.icon}</span>
                  <div>
                    <h3 className="font-bold text-sm">{info.label}</h3>
                    <p className="text-xs text-muted-foreground">{info.desc}</p>
                  </div>
                </div>
                {hasDate && (
                  <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-bold ${cfg.bg} ${cfg.color}`}>
                    {cfg.icon}<span>{cfg.label}</span>
                  </div>
                )}
              </div>

              {hasDate && (
                <div className={`rounded-lg p-3 ${cfg.bg} ${cfg.border} border`}>
                  <p className={`text-base font-bold ${cfg.color}`}>{daysLabel(days)}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    Vencimiento: {new Date(dates[key] + "T00:00:00").toLocaleDateString("es-CO", { day: "numeric", month: "long", year: "numeric" })}
                  </p>
                  {status === "vencido" && <p className="text-xs text-red-600 dark:text-red-400 font-semibold mt-1.5">⚠️ Documento vencido. Renovar antes de conducir para evitar comparendo e inmovilización.</p>}
                  {status === "critico" && <p className="text-xs text-orange-600 dark:text-orange-400 font-semibold mt-1.5">⏰ Quedan pocos días. Renovar a la brevedad para evitar sanciones.</p>}
                </div>
              )}

              <div className="space-y-1">
                <Label htmlFor={`date-${key}`} className="text-xs text-muted-foreground flex items-center gap-1">
                  <CalendarDays className="h-3 w-3" /> Fecha de vencimiento
                </Label>
                <Input
                  id={`date-${key}`}
                  type="date"
                  className="h-9 text-sm bg-muted/40 border-none"
                  value={dates[key]}
                  onChange={(e) => setDates(prev => ({ ...prev, [key]: e.target.value }))}
                  data-testid={`input-fecha-${key}`}
                />
              </div>

              <p className="text-[10px] text-muted-foreground/60 flex items-center gap-1">
                <Info className="h-2.5 w-2.5" /> {info.norma}
              </p>
            </CardContent>
          </Card>
        );
      })}

      {/* ── Tarjeta de recordatorios ── */}
      <Card className={`border-2 overflow-hidden shadow-md ${reminder.enabled && permission === "granted" ? "border-accent/50" : "border-border/40"}`}>
        <div className={`h-1 w-full ${reminder.enabled && permission === "granted" ? "bg-accent" : "bg-muted"}`} />
        <CardContent className="p-4 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {reminder.enabled && permission === "granted"
                ? <BellRing className="h-5 w-5 text-accent" />
                : <BellOff className="h-5 w-5 text-muted-foreground" />}
              <div>
                <h3 className="font-bold text-sm">Recordatorios</h3>
                <p className="text-xs text-muted-foreground">Notificaciones de vencimiento</p>
              </div>
            </div>
            {/* Toggle switch */}
            {permission === "granted" && (
              <button
                onClick={() => toggleReminder(!reminder.enabled)}
                data-testid="toggle-recordatorios"
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${reminder.enabled ? "bg-accent" : "bg-muted-foreground/30"}`}
              >
                <span className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform ${reminder.enabled ? "translate-x-6" : "translate-x-1"}`} />
              </button>
            )}
          </div>

          {/* Sin soporte */}
          {!notifSupported && (
            <div className="bg-muted/50 rounded-lg p-3 text-xs text-muted-foreground">
              Tu navegador no soporta notificaciones. Usa Chrome o Safari en iOS 16.4+ para activar recordatorios.
            </div>
          )}

          {/* Permiso no concedido */}
          {notifSupported && permission !== "granted" && (
            <div className="space-y-3">
              <p className="text-xs text-muted-foreground leading-relaxed">
                Activa las notificaciones del navegador para recibir un aviso automático cada vez que abras la app y algún documento esté próximo a vencer.
              </p>
              {permission === "denied" ? (
                <div className="bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 rounded-lg p-3">
                  <p className="text-xs text-red-700 dark:text-red-400 font-semibold">Permiso bloqueado</p>
                  <p className="text-xs text-red-600/80 dark:text-red-400/80 mt-1">
                    Ve a Configuración del navegador → Privacidad → Notificaciones → busca esta página y permite las notificaciones.
                  </p>
                </div>
              ) : (
                <Button
                  onClick={requestPermission}
                  className="w-full gap-2 font-semibold bg-accent hover:bg-accent/90 text-white"
                  data-testid="button-activar-notificaciones"
                >
                  <Bell className="h-4 w-4" />
                  Activar recordatorios
                </Button>
              )}
            </div>
          )}

          {/* Permiso concedido */}
          {notifSupported && permission === "granted" && (
            <div className="space-y-4">
              {/* Anticipación */}
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground flex items-center gap-1">
                  <ChevronDown className="h-3 w-3" /> Recordar con cuántos días de anticipación
                </Label>
                <Select value={String(reminder.advanceDays)} onValueChange={changeAdvance}>
                  <SelectTrigger className="h-9 text-sm bg-muted/40 border-none" data-testid="select-advance-days">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7">7 días antes</SelectItem>
                    <SelectItem value="15">15 días antes</SelectItem>
                    <SelectItem value="30">30 días antes</SelectItem>
                    <SelectItem value="60">60 días antes</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Estado actual */}
              <div className={`rounded-lg p-3 text-xs space-y-1 ${reminder.enabled ? "bg-accent/5 border border-accent/20" : "bg-muted/40"}`}>
                <p className="font-semibold">
                  {reminder.enabled ? "🔔 Recordatorios activos" : "🔕 Recordatorios desactivados"}
                </p>
                <p className="text-muted-foreground leading-relaxed">
                  {reminder.enabled
                    ? `Recibirás una notificación al abrir la app si algún documento vence en los próximos ${reminder.advanceDays} días o ya está vencido. Máximo una notificación por documento al día.`
                    : "Activa el interruptor para recibir recordatorios cuando abras la app."}
                </p>
              </div>

              {/* Notificación de prueba */}
              {reminder.enabled && (
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full gap-2 text-xs"
                  onClick={sendTestNotification}
                  data-testid="button-test-notificacion"
                >
                  {testSent ? <><CheckCircle className="h-3.5 w-3.5 text-green-500" /> Enviada</> : <><BellRing className="h-3.5 w-3.5 text-accent" /> Enviar notificación de prueba</>}
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Botones guardar / limpiar */}
      <div className="flex gap-3">
        <Button className="flex-1 gap-2 font-semibold" onClick={save} data-testid="button-guardar-documentos">
          {saved ? <><CheckCircle className="h-4 w-4" /> Guardado</> : <><FileCheck className="h-4 w-4" /> Guardar fechas</>}
        </Button>
        <Button variant="outline" size="icon" onClick={reset} data-testid="button-limpiar-documentos" title="Borrar todas las fechas">
          <RotateCcw className="h-4 w-4 text-muted-foreground" />
        </Button>
      </div>

      <p className="text-center text-xs text-muted-foreground px-4 leading-snug">
        Las fechas y preferencias se guardan en tu dispositivo. La notificación se dispara cada vez que abres la app, máximo una vez al día por documento.
      </p>
    </div>
  );
}
