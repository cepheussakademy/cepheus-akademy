import { useState } from "react";
import { Scale, MessageCircle, MapPin, Navigation, Star, Shield, ExternalLink, AlertTriangle, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";

type EstadoGeo = "idle" | "buscando" | "listo" | "error";

const WA_NUMBER = "573136531207";
const WA_MESSAGE = encodeURIComponent(
  "Hola, me comunicó desde la aplicación Cepheus Transit. Necesito asesoría jurídica en derecho de tránsito."
);

export default function Abogados() {
  const [estadoGeo, setEstadoGeo] = useState<EstadoGeo>("idle");
  const [errorMsg, setErrorMsg] = useState("");

  const abrirMapsConUbicacion = (lat: number, lng: number) => {
    const query = encodeURIComponent("abogado de tránsito derecho vial");
    const url = `https://www.google.com/maps/search/${query}/@${lat},${lng},14z`;
    window.open(url, "_blank");
    setEstadoGeo("listo");
  };

  const abrirMapsSinUbicacion = () => {
    window.open(
      "https://www.google.com/maps/search/abogado+derecho+de+transito+Colombia",
      "_blank"
    );
    setEstadoGeo("listo");
  };

  const buscarCercanos = () => {
    if (!navigator.geolocation) {
      setErrorMsg("Tu navegador no soporta geolocalización.");
      setEstadoGeo("error");
      return;
    }
    setEstadoGeo("buscando");
    setErrorMsg("");
    navigator.geolocation.getCurrentPosition(
      (pos) => abrirMapsConUbicacion(pos.coords.latitude, pos.coords.longitude),
      (err) => {
        let msg = "No fue posible obtener tu ubicación.";
        if (err.code === 1) msg = "Permiso de ubicación denegado. Puedes activarlo en la configuración del navegador.";
        if (err.code === 3) msg = "La solicitud de ubicación tardó demasiado.";
        setErrorMsg(msg);
        setEstadoGeo("error");
      },
      { timeout: 10000, enableHighAccuracy: true }
    );
  };

  return (
    <div className="flex flex-col h-full animate-in fade-in p-4 pb-24 gap-5">

      {/* Header */}
      <div className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground p-6 rounded-2xl shadow-xl shadow-primary/20">
        <div className="flex items-center gap-3">
          <div className="bg-accent/20 p-2 rounded-xl">
            <Scale className="h-8 w-8 text-accent" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Asesoría Jurídica</h1>
            <p className="text-primary-foreground/75 text-sm">Especialistas en derecho de tránsito</p>
          </div>
        </div>
      </div>

      {/* Tarjeta destacada — Galvis Castro Abogados */}
      <Card className="border-2 border-accent/40 shadow-xl overflow-hidden">
        <div className="h-1.5 bg-gradient-to-r from-accent via-orange-400 to-accent w-full" />
        <CardContent className="p-5 space-y-4">

          {/* Badge aliado */}
          <div className="flex items-center justify-between">
            <Badge className="bg-accent text-white gap-1.5 text-xs py-1 px-3">
              <Star className="h-3 w-3 fill-white" />
              Aliado Cepheus Transit
            </Badge>
            <Badge variant="outline" className="text-xs text-muted-foreground">
              Consulta sin costo inicial
            </Badge>
          </div>

          {/* Nombre y descripción */}
          <div>
            <h2 className="text-xl font-bold text-primary">Galvis Castro Abogados</h2>
            <div className="flex items-center gap-1.5 mt-1 text-sm text-muted-foreground">
              <Shield className="h-3.5 w-3.5 text-accent shrink-0" />
              <span>Derecho de tránsito · Infracciones · Accidentes viales</span>
            </div>
          </div>

          {/* Servicios */}
          <div className="flex flex-wrap gap-1.5">
            {[
              "Comparendos",
              "Recursos de reposición",
              "Apelaciones",
              "Accidentes de tránsito",
              "Suspensión de licencia",
              "Embriaguez al volante",
            ].map((s) => (
              <Badge key={s} variant="secondary" className="text-xs bg-primary/5 text-primary">
                {s}
              </Badge>
            ))}
          </div>

          {/* Contacto */}
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Phone className="h-3.5 w-3.5 text-accent" />
            <span>+57 313 6531207</span>
          </div>

          {/* Botón WhatsApp */}
          <Button
            data-testid="button-whatsapp-galvis"
            className="w-full h-13 text-base font-bold bg-green-600 hover:bg-green-700 text-white gap-3"
            size="lg"
            onClick={() =>
              window.open(`https://wa.me/${WA_NUMBER}?text=${WA_MESSAGE}`, "_blank")
            }
          >
            <MessageCircle className="h-5 w-5" />
            Contactar por WhatsApp
          </Button>
        </CardContent>
      </Card>

      {/* Separador */}
      <div className="flex items-center gap-3">
        <div className="h-px flex-1 bg-border" />
        <span className="text-xs text-muted-foreground">También puedes buscar</span>
        <div className="h-px flex-1 bg-border" />
      </div>

      {/* Tarjeta búsqueda en Maps */}
      <Card className="border-none shadow-md">
        <CardContent className="p-5 flex flex-col items-center gap-4 text-center">
          <div className="bg-primary/10 rounded-full p-4">
            <Navigation className="h-8 w-8 text-primary" />
          </div>
          <div>
            <h3 className="font-bold text-base">Abogados cercanos a ti</h3>
            <p className="text-sm text-muted-foreground mt-1 leading-relaxed">
              Usa tu ubicación para ver en Google Maps los abogados especialistas en tránsito más cercanos.
            </p>
          </div>

          <Button
            data-testid="button-buscar-abogados-mapa"
            onClick={buscarCercanos}
            disabled={estadoGeo === "buscando"}
            className="w-full gap-2 font-semibold"
            variant="outline"
          >
            {estadoGeo === "buscando" ? (
              <>
                <span className="animate-spin rounded-full h-4 w-4 border-2 border-primary border-t-transparent" />
                Obteniendo ubicación...
              </>
            ) : (
              <>
                <MapPin className="h-4 w-4 text-primary" />
                Ver abogados cercanos en Maps
              </>
            )}
          </Button>

          <button
            className="text-xs text-muted-foreground underline underline-offset-2"
            onClick={abrirMapsSinUbicacion}
            data-testid="button-maps-sin-ubicacion"
          >
            Buscar sin compartir mi ubicación
          </button>
        </CardContent>
      </Card>

      {/* Error geolocalización */}
      {estadoGeo === "error" && (
        <Alert className="border-orange-300 bg-orange-50 dark:bg-orange-950/30 dark:border-orange-800 animate-in fade-in">
          <AlertTriangle className="h-4 w-4 text-orange-600 dark:text-orange-400" />
          <AlertDescription className="text-sm text-orange-800 dark:text-orange-300">
            <p className="font-semibold mb-1">No se pudo obtener tu ubicación</p>
            <p>{errorMsg}</p>
            <Button
              variant="outline"
              size="sm"
              className="mt-3 gap-2 border-orange-400 text-orange-700 dark:text-orange-400"
              onClick={abrirMapsSinUbicacion}
            >
              <ExternalLink className="h-3.5 w-3.5" />
              Abrir búsqueda general en Maps
            </Button>
          </AlertDescription>
        </Alert>
      )}

      {/* Confirmación */}
      {estadoGeo === "listo" && (
        <Alert className="border-green-300 bg-green-50 dark:bg-green-950/30 dark:border-green-800 animate-in fade-in">
          <MapPin className="h-4 w-4 text-green-600 dark:text-green-400" />
          <AlertDescription className="text-sm text-green-800 dark:text-green-300">
            Google Maps se abrió con abogados cercanos a tu ubicación.
          </AlertDescription>
        </Alert>
      )}

      <p className="text-center text-xs text-muted-foreground px-4">
        Cepheus Transit no garantiza resultados jurídicos. La información es de carácter referencial. La ubicación no es almacenada.
      </p>
    </div>
  );
}
