import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search, AlertTriangle, BookOpen, FileText, Landmark,
  Calculator, ChevronDown, ChevronUp, ExternalLink, Shield,
  Clock, Scale, Zap, Info
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import infraccionesData from "@/data/infracciones.json";

// ─── SMMLV 2025 por defecto ───────────────────────────────────────────────────
const SMMLV_DEFAULT = 1_423_500;

// ─── Tipos ────────────────────────────────────────────────────────────────────
type Infraccion = {
  codigo: string;
  descripcion: string;
  grupo: string;
  smldv_base: number;
  smldv_con_descuento: number;
  smldv_reincidencia?: number;
  rango_alcoholemia?: string;
  norma_base: string;
  articulo: string;
  implica_inmovilizacion: boolean;
  aplica_descuento_50pct: boolean;
  implica_suspension_licencia: boolean;
  meses_suspension_min: number | null;
  meses_suspension_max: number | null;
  prescripcion_anos: number;
  es_fotomulta: boolean;
  proceso_defensa_disponible: boolean;
  explicacion_ciudadano: string;
  observaciones_tecnicas: string;
  tags_busqueda: string[];
};

const data = infraccionesData as Infraccion[];

// ─── Configuración visual por grupo ──────────────────────────────────────────
const GRUPO_CONFIG: Record<string, { label: string; color: string; bg: string; border: string }> = {
  A: { label: "Grupo A", color: "text-blue-700 dark:text-blue-300",   bg: "bg-blue-50 dark:bg-blue-950/40",   border: "border-blue-200 dark:border-blue-800" },
  B: { label: "Grupo B", color: "text-green-700 dark:text-green-300", bg: "bg-green-50 dark:bg-green-950/40", border: "border-green-200 dark:border-green-800" },
  C: { label: "Grupo C", color: "text-amber-700 dark:text-amber-300", bg: "bg-amber-50 dark:bg-amber-950/40", border: "border-amber-200 dark:border-amber-800" },
  D: { label: "Grupo D", color: "text-red-700 dark:text-red-300",     bg: "bg-red-50 dark:bg-red-950/40",     border: "border-red-200 dark:border-red-800" },
  E: { label: "Grupo E", color: "text-orange-700 dark:text-orange-300", bg: "bg-orange-50 dark:bg-orange-950/40", border: "border-orange-200 dark:border-orange-800" },
  F: { label: "Grupo F", color: "text-purple-700 dark:text-purple-300", bg: "bg-purple-50 dark:bg-purple-950/40", border: "border-purple-200 dark:border-purple-800" },
};

// ─── Formateo COP ─────────────────────────────────────────────────────────────
const toCOP = (smldv: number, smmlv: number) =>
  Math.round(smldv * (smmlv / 30)).toLocaleString("es-CO", { style: "currency", currency: "COP", maximumFractionDigits: 0 });

export default function Infracciones() {
  const [searchTerm, setSearchTerm]     = useState("");
  const [grupoFilter, setGrupoFilter]   = useState("Todos");
  const [smmlv, setSmmlv]               = useState<number>(SMMLV_DEFAULT);
  const [showCalc, setShowCalc]         = useState(false);
  const [smmlvInput, setSmmlvInput]     = useState(String(SMMLV_DEFAULT));

  const grupos = ["Todos", "B", "C", "D", "F"];

  const filtered = useMemo(() => {
    let result = data;
    if (grupoFilter !== "Todos") result = result.filter(i => i.grupo === grupoFilter);
    if (searchTerm) {
      const lower = searchTerm.toLowerCase();
      result = result.filter(i =>
        i.codigo.toLowerCase().includes(lower) ||
        i.descripcion.toLowerCase().includes(lower) ||
        i.norma_base.toLowerCase().includes(lower) ||
        i.articulo.toLowerCase().includes(lower) ||
        i.explicacion_ciudadano.toLowerCase().includes(lower) ||
        i.tags_busqueda.some(t => t.toLowerCase().includes(lower))
      );
    }
    return result;
  }, [searchTerm, grupoFilter]);

  const applySmmlv = () => {
    const parsed = parseInt(smmlvInput.replace(/\D/g, ""), 10);
    if (!isNaN(parsed) && parsed > 0) setSmmlv(parsed);
  };

  const cfg = (grupo: string) => GRUPO_CONFIG[grupo] ?? GRUPO_CONFIG["A"];

  return (
    <div className="flex flex-col h-full animate-in fade-in duration-300">

      {/* ── Sticky header ── */}
      <div className="sticky top-14 z-30 bg-background/95 backdrop-blur-sm border-b shadow-sm">
        <div className="p-3 space-y-2">
          {/* Buscador */}
          <div className="relative">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Código (D04), descripción o palabra clave..."
              className="pl-9 h-9 bg-muted/50 border-none text-sm"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              data-testid="input-buscar-infraccion"
            />
          </div>

          {/* Filtro grupos */}
          <div className="flex gap-1.5 overflow-x-auto pb-0.5 scrollbar-none">
            {grupos.map(g => {
              const active = grupoFilter === g;
              const c = g !== "Todos" ? cfg(g) : null;
              return (
                <button
                  key={g}
                  onClick={() => setGrupoFilter(g)}
                  className={`shrink-0 px-3 py-1 rounded-full text-xs font-semibold border transition-colors ${
                    active
                      ? c ? `${c.bg} ${c.color} ${c.border}` : "bg-primary text-primary-foreground border-primary"
                      : "bg-muted/50 text-muted-foreground border-transparent"
                  }`}
                  data-testid={`filtro-grupo-${g}`}
                >
                  {g === "Todos" ? "Todos" : `Grupo ${g} · ${g === "B" ? "8" : g === "C" ? "15" : g === "D" ? "30" : "90–720"} SMLDV`}
                </button>
              );
            })}
          </div>

          {/* Toggle calculadora COP */}
          <button
            onClick={() => setShowCalc(v => !v)}
            className="flex items-center gap-1.5 text-xs text-accent font-medium"
            data-testid="toggle-calculadora"
          >
            <Calculator className="h-3.5 w-3.5" />
            Ver equivalente en pesos (COP)
            {showCalc ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
          </button>

          {showCalc && (
            <div className="bg-muted/40 rounded-lg p-3 space-y-2 animate-in fade-in">
              <p className="text-xs text-muted-foreground leading-snug">
                <strong>Fórmula:</strong> valor COP = SMLDV × (SMMLV ÷ 30). El resultado es orientativo; la sanción oficial está en SMLDV.
              </p>
              <div className="flex gap-2">
                <Input
                  type="number"
                  placeholder="SMMLV mensual vigente"
                  className="h-8 text-xs bg-background border-border"
                  value={smmlvInput}
                  onChange={(e) => setSmmlvInput(e.target.value)}
                  onBlur={applySmmlv}
                  onKeyDown={(e) => e.key === "Enter" && applySmmlv()}
                  data-testid="input-smmlv"
                />
                <Button size="sm" className="h-8 text-xs shrink-0" onClick={applySmmlv}>Aplicar</Button>
              </div>
              <p className="text-xs text-muted-foreground">SMMLV usado: {smmlv.toLocaleString("es-CO")} COP/mes · Valor diario: {Math.round(smmlv / 30).toLocaleString("es-CO")} COP</p>
            </div>
          )}
        </div>
      </div>

      {/* ── Listado ── */}
      <div className="p-3 flex-1 overflow-y-auto pb-24 space-y-3">
        {/* Contador */}
        <p className="text-xs text-muted-foreground px-1">
          {filtered.length} infracción{filtered.length !== 1 ? "es" : ""} encontrada{filtered.length !== 1 ? "s" : ""}
        </p>

        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-52 text-center px-4">
            <Search className="h-12 w-12 text-muted-foreground/30 mb-3" />
            <h3 className="font-semibold">Sin resultados</h3>
            <p className="text-sm text-muted-foreground mt-1">Intenta con "cinturón", "semáforo", "celular" o el código exacto.</p>
          </div>
        ) : (
          <AnimatePresence>
            {filtered.map((inf, i) => {
              const c = cfg(inf.grupo);
              const isF = inf.grupo === "F";
              const suspMin = inf.meses_suspension_min;
              const suspMax = inf.meses_suspension_max;
              const isCancelacion = inf.implica_suspension_licencia && suspMin === null && suspMax === null;

              return (
                <motion.div
                  key={inf.codigo}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  transition={{ delay: Math.min(i * 0.04, 0.25) }}
                  layout
                >
                  <Card className={`overflow-hidden border shadow-md ${c.border}`}>
                    {/* Franja de color del grupo */}
                    <div className={`h-1 w-full ${c.bg.replace("bg-", "bg-").replace("/40", "")}`}
                         style={{ background: isF ? "linear-gradient(90deg, #7c3aed, #a855f7)" :
                                               inf.grupo === "D" ? "linear-gradient(90deg, #dc2626, #ef4444)" :
                                               inf.grupo === "C" ? "linear-gradient(90deg, #d97706, #f59e0b)" :
                                               "linear-gradient(90deg, #16a34a, #22c55e)" }} />

                    <CardContent className="p-4 space-y-3">
                      {/* Cabecera */}
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className={`font-mono text-sm font-bold px-2 py-0.5 rounded ${c.bg} ${c.color}`}>
                              {inf.codigo}
                            </span>
                            <Badge variant="outline" className={`text-[10px] ${c.color} ${c.border}`}>
                              {c.label}
                            </Badge>
                            {inf.es_fotomulta && (
                              <Badge variant="outline" className="text-[10px] gap-0.5 text-muted-foreground">
                                <Zap className="h-2.5 w-2.5" /> Fotomulta
                              </Badge>
                            )}
                          </div>
                          <p className="font-semibold text-sm mt-1.5 leading-snug">{inf.descripcion}</p>
                          {inf.rango_alcoholemia && (
                            <p className="text-xs text-muted-foreground mt-0.5">{inf.rango_alcoholemia}</p>
                          )}
                        </div>
                        {inf.implica_inmovilizacion && (
                          <Badge variant="destructive" className="shrink-0 gap-1 text-[10px]">
                            <AlertTriangle className="h-2.5 w-2.5" /> Inmovilización
                          </Badge>
                        )}
                      </div>

                      {/* Bloque de sanciones */}
                      <div className={`rounded-lg p-3 ${c.bg} ${c.border} border space-y-2`}>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-0.5">Multa</p>
                            <p className={`text-xl font-bold font-mono ${c.color}`}>{inf.smldv_base} <span className="text-xs font-normal">SMLDV</span></p>
                            {showCalc && <p className="text-xs text-muted-foreground">{toCOP(inf.smldv_base, smmlv)}</p>}
                          </div>
                          {inf.aplica_descuento_50pct ? (
                            <div>
                              <p className="text-[10px] font-semibold uppercase tracking-wider text-green-700 dark:text-green-400 mb-0.5">Con descuento (5 días)</p>
                              <p className="text-xl font-bold font-mono text-green-700 dark:text-green-400">{inf.smldv_con_descuento} <span className="text-xs font-normal">SMLDV</span></p>
                              {showCalc && <p className="text-xs text-green-700/70 dark:text-green-400/70">{toCOP(inf.smldv_con_descuento, smmlv)}</p>}
                            </div>
                          ) : (
                            <div>
                              <p className="text-[10px] font-semibold uppercase tracking-wider text-red-600 dark:text-red-400 mb-0.5">Sin descuento</p>
                              <p className="text-xs text-red-600 dark:text-red-400 font-medium mt-1">No aplica el 50% (Art. 136 CNT)</p>
                            </div>
                          )}
                        </div>

                        {inf.smldv_reincidencia && (
                          <div className="border-t border-current/10 pt-2">
                            <p className="text-[10px] font-semibold uppercase tracking-wider text-red-600 dark:text-red-400 mb-0.5">Reincidencia</p>
                            <p className="text-sm font-bold font-mono text-red-600 dark:text-red-400">
                              {inf.smldv_reincidencia.toLocaleString()} SMLDV
                              {showCalc && <span className="text-xs font-normal ml-1 text-muted-foreground">≈ {toCOP(inf.smldv_reincidencia, smmlv)}</span>}
                            </p>
                          </div>
                        )}
                      </div>

                      {/* Badges de consecuencias adicionales */}
                      <div className="flex flex-wrap gap-1.5">
                        {inf.implica_suspension_licencia && (
                          <Badge variant="secondary" className="gap-1 text-[10px] bg-orange-100 text-orange-700 dark:bg-orange-950/40 dark:text-orange-300">
                            <Shield className="h-2.5 w-2.5" />
                            {isCancelacion
                              ? "Cancelación definitiva de licencia"
                              : `Suspensión ${suspMin}–${suspMax} meses`}
                          </Badge>
                        )}
                        {inf.prescripcion_anos && (
                          <Badge variant="secondary" className="gap-1 text-[10px]">
                            <Clock className="h-2.5 w-2.5" />
                            Prescribe en {inf.prescripcion_anos} años
                          </Badge>
                        )}
                      </div>

                      {/* Alerta proceso de defensa */}
                      {inf.proceso_defensa_disponible && (
                        <div className="flex gap-2 rounded-lg border border-accent/30 bg-accent/5 p-2.5">
                          <Scale className="h-4 w-4 text-accent shrink-0 mt-0.5" />
                          <div>
                            <p className="text-xs font-semibold text-accent">Proceso de defensa disponible</p>
                            <p className="text-xs text-muted-foreground mt-0.5">
                              Esta infracción admite recursos de reposición, nulidades procesales o audiencias de descargo. Consulta un especialista.
                            </p>
                          </div>
                        </div>
                      )}

                      {/* Explicación ciudadana */}
                      <div className="flex gap-2">
                        <Info className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                        <p className="text-sm text-muted-foreground leading-relaxed">{inf.explicacion_ciudadano}</p>
                      </div>

                      {/* Detalles técnicos */}
                      <Accordion type="single" collapsible>
                        <AccordionItem value="tech" className="border-none">
                          <AccordionTrigger className="py-1.5 text-xs font-semibold hover:no-underline text-muted-foreground [&[data-state=open]]:text-accent">
                            Detalles técnicos y normativos
                          </AccordionTrigger>
                          <AccordionContent className="pt-2 space-y-3">
                            <div>
                              <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground mb-1">Normatividad</p>
                              <p className="text-sm">{inf.norma_base} · {inf.articulo}</p>
                            </div>
                            <div>
                              <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground mb-1 flex items-center gap-1">
                                <FileText className="h-3 w-3" /> Observaciones técnicas
                              </p>
                              <p className="text-sm text-muted-foreground leading-relaxed">{inf.observaciones_tecnicas}</p>
                            </div>
                          </AccordionContent>
                        </AccordionItem>
                      </Accordion>

                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </AnimatePresence>
        )}

        {/* ── Herramientas oficiales ── */}
        <div className="pt-2 pb-2 space-y-2">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider px-1">Herramientas oficiales</p>
          <div className="grid grid-cols-2 gap-2">
            <Button
              variant="outline"
              size="sm"
              className="text-xs gap-1.5 h-10"
              onClick={() => window.open("https://www.runt.com.co", "_blank")}
              data-testid="button-runt"
            >
              <ExternalLink className="h-3.5 w-3.5 text-primary" /> RUNT
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="text-xs gap-1.5 h-10"
              onClick={() => window.open("https://www.fcm.org.co/simit", "_blank")}
              data-testid="button-simit"
            >
              <ExternalLink className="h-3.5 w-3.5 text-accent" /> SIMIT
            </Button>
          </div>
          <p className="text-[10px] text-muted-foreground text-center leading-snug">
            RUNT: consulta licencias, vehículos y RTM · SIMIT: verifica comparendos y multas
          </p>
        </div>

        <p className="text-center text-[10px] text-muted-foreground/60 pb-2 leading-snug">
          Valores en SMLDV según Ley 769/2002, Ley 1383/2010 y Ley 1696/2013. Conversión a COP es orientativa.
          Descuento del 50% aplica dentro de los primeros 5 días hábiles (Art. 136 CNT).
        </p>
      </div>
    </div>
  );
}
