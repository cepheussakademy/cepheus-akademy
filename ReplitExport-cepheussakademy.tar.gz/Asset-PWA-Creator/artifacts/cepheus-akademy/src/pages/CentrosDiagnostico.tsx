import { useState } from "react";
import { Wrench, MapPin, Navigation, ExternalLink, AlertTriangle, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";

type Estado = "idle" | "buscando" | "listo" | "error";

export default function CentrosDiagnostico() {
  const [estado, setEstado] = useState<Estado>("idle");
  const [errorMsg, setErrorMsg] = useState("");

  const abrirEnMaps = (lat: number, lng: number) => {
    const query = encodeURIComponent("centro de diagnóstico automotor CDA revisión técnico-mecánica");
    const url = `https://www.google.com/maps/search/${query}/@${lat},${lng},14z`;
    window.open(url, "_blank");
    setEstado("listo");
  };

  const abrirSinUbicacion = () => {
    window.open(
      "https://www.google.com/maps/search/centro+de+diagnostico+automotor+CDA+Colombia",
      "_blank"
    );
    setEstado("listo");
  };

  const buscarCercanos = () => {
    if (!navigator.geolocation) {
      setErrorMsg("Tu navegador no soporta geolocalización.");
      setEstado("error");
      return;
    }
    setEstado("buscando");
    setErrorMsg("");
    navigator.geolocation.getCurrentPosition(
      (pos) => abrirEnMaps(pos.coords.latitude, pos.coords.longitude),
      (err) => {
        let msg = "No fue posible obtener tu ubicación.";
        if (err.code === 1) msg = "Permiso de ubicación denegado. Puedes activarlo en la configuración de tu navegador.";
        if (err.code === 2) msg = "No se pudo determinar tu ubicación en este momento.";
        if (err.code === 3) msg = "La solicitud de ubicación tardó demasiado.";
        setErrorMsg(msg);
        setEstado("error");
      },
      { timeout: 10000, enableHighAccuracy: true }
    );
  };

  return (
    <div className="flex flex-col h-full animate-in fade-in p-4 pb-24 gap-5">

      {/* Header */}
      <div className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground p-6 rounded-2xl shadow-xl shadow-primary/20">
        <div className="flex items-center gap-3">
          <div className="bg-accent/20 p-2 rounded-xl">
            <Wrench className="h-8 w-8 text-accent" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Centros de Diagnóstico</h1>
            <p className="text-primary-foreground/75 text-sm">Revisión técnico-mecánica — CDA</p>
          </div>
        </div>
      </div>

      {/* Botón principal */}
      <Card className="border-none shadow-lg">
        <CardContent className="p-6 flex flex-col items-center gap-5 text-center">
          <div className="bg-accent/10 rounded-full p-5">
            <Navigation className="h-10 w-10 text-accent" />
          </div>

          <div>
            <h2 className="text-lg font-bold mb-1">Encuentra el CDA más cercano</h2>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Usamos tu ubicación actual para mostrarte en Google Maps los Centros de Diagnóstico Automotor habilitados más cercanos a ti.
            </p>
          </div>

          <Button
            data-testid="button-buscar-centros-cercanos"
            onClick={buscarCercanos}
            disabled={estado === "buscando"}
            className="w-full h-14 text-base font-bold bg-accent hover:bg-accent/90 text-white gap-3"
            size="lg"
          >
            {estado === "buscando" ? (
              <>
                <span className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent" />
                Obteniendo ubicación...
              </>
            ) : (
              <>
                <MapPin className="h-5 w-5" />
                Buscar CDA cercanos
              </>
            )}
          </Button>

          {estado !== "idle" && estado !== "buscando" && (
            <Button
              variant="outline"
              className="w-full gap-2"
              onClick={abrirSinUbicacion}
              data-testid="button-buscar-sin-ubicacion"
            >
              <ExternalLink className="h-4 w-4" />
              Buscar en Google Maps sin usar mi ubicación
            </Button>
          )}

          {estado === "idle" && (
            <button
              className="text-xs text-muted-foreground underline underline-offset-2"
              onClick={abrirSinUbicacion}
              data-testid="button-sin-ubicacion-link"
            >
              Buscar sin compartir mi ubicación
            </button>
          )}
        </CardContent>
      </Card>

      {/* Error geolocalización */}
      {estado === "error" && (
        <Alert className="border-orange-300 bg-orange-50 dark:bg-orange-950/30 dark:border-orange-800 animate-in fade-in">
          <AlertTriangle className="h-4 w-4 text-orange-600 dark:text-orange-400" />
          <AlertDescription className="text-sm text-orange-800 dark:text-orange-300">
            <p className="font-semibold mb-1">No se pudo obtener tu ubicación</p>
            <p>{errorMsg}</p>
            <Button
              variant="outline"
              size="sm"
              className="mt-3 gap-2 border-orange-400 text-orange-700 dark:text-orange-400"
              onClick={abrirSinUbicacion}
            >
              <ExternalLink className="h-3.5 w-3.5" />
              Abrir búsqueda general en Maps
            </Button>
          </AlertDescription>
        </Alert>
      )}

      {/* Confirmación */}
      {estado === "listo" && (
        <Alert className="border-green-300 bg-green-50 dark:bg-green-950/30 dark:border-green-800 animate-in fade-in">
          <MapPin className="h-4 w-4 text-green-600 dark:text-green-400" />
          <AlertDescription className="text-sm text-green-800 dark:text-green-300">
            Google Maps se abrió con los centros de diagnóstico cercanos a tu ubicación.
          </AlertDescription>
        </Alert>
      )}

      {/* Info normativa */}
      <Card className="border-border/40 shadow-sm">
        <CardContent className="p-4 space-y-3">
          <div className="flex items-center gap-2">
            <Info className="h-4 w-4 text-primary shrink-0" />
            <h3 className="font-semibold text-sm">¿Qué es un CDA?</h3>
          </div>
          <p className="text-xs text-muted-foreground leading-relaxed">
            Los <strong>Centros de Diagnóstico Automotor (CDA)</strong> son los únicos organismos habilitados por el Ministerio de Transporte para realizar la revisión técnico-mecánica y de gases contaminantes exigida por el Código Nacional de Tránsito (Ley 769/2002).
          </p>
          <div className="bg-muted/40 rounded-lg p-3 space-y-1">
            <p className="text-xs font-semibold">Antes de hacer tu revisión verifica en el RUNT:</p>
            <ul className="text-xs text-muted-foreground space-y-0.5 list-disc pl-4">
              <li>Que el CDA esté habilitado y con certificación vigente</li>
              <li>Que atienda el tipo de vehículo que tienes (moto, liviano, carga)</li>
              <li>Que cuente con equipos calibrados y certificados</li>
            </ul>
          </div>
          <Button
            variant="outline"
            size="sm"
            className="w-full gap-2 text-xs"
            onClick={() => window.open("https://www.runt.com.co", "_blank")}
            data-testid="button-runt"
          >
            <ExternalLink className="h-3.5 w-3.5 text-accent" />
            Consultar habilitación en RUNT
          </Button>
        </CardContent>
      </Card>

      <p className="text-center text-xs text-muted-foreground px-4">
        Cepheus Transit no está afiliado a ningún CDA. La ubicación se usa únicamente para la búsqueda en Google Maps y no es almacenada.
      </p>
    </div>
  );
}
