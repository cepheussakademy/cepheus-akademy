import { Link } from "wouter";
import { Search, ShieldAlert, Scale, MapPin, BookOpen, Headset, GraduationCap, Wrench, MonitorPlay, FileCheck } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Home() {
  return (
    <div className="flex-1 flex flex-col pt-6 pb-24 px-4 gap-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col gap-2 bg-gradient-to-br from-primary to-primary/80 text-primary-foreground p-6 rounded-2xl shadow-xl shadow-primary/20">
        <h1 className="text-3xl font-bold tracking-tight">Cepheus Transit</h1>
        <p className="text-primary-foreground/80 font-medium">Seguridad Jurídica y Técnica en Tránsito</p>
      </div>

      <div className="grid grid-cols-2 gap-4 mt-2">
        <Link href="/infracciones">
          <Button variant="outline" data-testid="button-infracciones" className="w-full h-32 flex flex-col gap-3 justify-center items-center shadow-sm hover:border-accent hover:bg-accent/5">
            <Search className="h-8 w-8 text-accent" />
            <span className="font-semibold text-sm">Buscar Infracción</span>
          </Button>
        </Link>

        <Link href="/accidente">
          <Button variant="outline" data-testid="button-accidente" className="w-full h-32 flex flex-col gap-3 justify-center items-center shadow-sm hover:border-destructive hover:bg-destructive/5">
            <ShieldAlert className="h-8 w-8 text-destructive" />
            <span className="font-semibold text-sm">Tuve un Accidente</span>
          </Button>
        </Link>

        <Link href="/alcoholemia">
          <Button variant="outline" data-testid="button-alcoholemia" className="w-full h-32 flex flex-col gap-3 justify-center items-center shadow-sm hover:border-accent hover:bg-accent/5">
            <Scale className="h-8 w-8 text-accent" />
            <span className="font-semibold text-sm">Validador Alcoholemia</span>
          </Button>
        </Link>

        <Link href="/hospitales">
          <Button variant="outline" data-testid="button-hospitales" className="w-full h-32 flex flex-col gap-3 justify-center items-center shadow-sm">
            <MapPin className="h-8 w-8 text-primary" />
            <span className="font-semibold text-sm">Hospitales Cercanos</span>
          </Button>
        </Link>

        <Link href="/biblioteca">
          <Button variant="outline" data-testid="button-biblioteca" className="w-full h-32 flex flex-col gap-3 justify-center items-center shadow-sm">
            <BookOpen className="h-8 w-8 text-primary" />
            <span className="font-semibold text-sm">Biblioteca</span>
          </Button>
        </Link>

        <Link href="/documentos">
          <Button variant="outline" data-testid="button-documentos" className="w-full h-32 flex flex-col gap-3 justify-center items-center shadow-sm hover:border-green-500 hover:bg-green-50 dark:hover:bg-green-950/20">
            <FileCheck className="h-8 w-8 text-green-600 dark:text-green-400" />
            <span className="font-semibold text-sm">Vigencia Documentos</span>
          </Button>
        </Link>

        <Link href="/escuelas">
          <Button variant="outline" data-testid="button-escuelas" className="w-full h-32 flex flex-col gap-3 justify-center items-center shadow-sm hover:border-accent hover:bg-accent/5">
            <GraduationCap className="h-8 w-8 text-accent" />
            <span className="font-semibold text-sm">Escuelas de Conducción</span>
          </Button>
        </Link>

        <Link href="/centros-diagnostico">
          <Button variant="outline" data-testid="button-centros-diagnostico" className="w-full h-32 flex flex-col gap-3 justify-center items-center shadow-sm hover:border-primary hover:bg-primary/5">
            <Wrench className="h-8 w-8 text-primary" />
            <span className="font-semibold text-sm">Centros de Diagnóstico</span>
          </Button>
        </Link>

        <button
          data-testid="button-cepheus-akademy"
          onClick={() => window.open("https://www.cepheussakademy.com", "_blank")}
          className="col-span-2 w-full"
        >
          <div className="w-full h-20 flex flex-row gap-4 justify-center items-center shadow-md rounded-md border-2 border-primary/40 bg-primary/5 hover:bg-primary/10 hover:border-primary/60 transition-colors px-5">
            <MonitorPlay className="h-7 w-7 shrink-0 text-primary" />
            <div className="flex flex-col items-start">
              <span className="font-bold text-sm leading-tight text-primary">Plataforma Educativa</span>
              <span className="text-xs text-muted-foreground leading-tight">cepheussakademy.com</span>
            </div>
          </div>
        </button>

        <Link href="/abogados" className="col-span-2">
          <Button
            data-testid="button-asesores-accidente"
            className="w-full h-20 flex flex-row gap-4 justify-center items-center shadow-md bg-accent hover:bg-accent/90 text-white border-0"
          >
            <Headset className="h-7 w-7 shrink-0" />
            <div className="flex flex-col items-start">
              <span className="font-bold text-sm leading-tight">Asesores en Accidente</span>
              <span className="text-xs text-white/75 leading-tight">Contacta un especialista ahora</span>
            </div>
          </Button>
        </Link>
      </div>
    </div>
  );
}
