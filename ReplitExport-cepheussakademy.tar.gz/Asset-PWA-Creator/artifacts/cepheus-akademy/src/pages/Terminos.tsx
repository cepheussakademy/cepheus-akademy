import { FileText, Shield, AlertTriangle } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export default function Terminos() {
  return (
    <div className="flex flex-col h-full animate-in fade-in pb-24 p-4">
      <div className="text-center py-6">
        <div className="inline-flex bg-primary/10 p-4 rounded-full text-primary mb-4">
          <FileText className="h-8 w-8" />
        </div>
        <h1 className="text-2xl font-bold tracking-tight mb-2">Términos y Responsabilidad</h1>
        <p className="text-muted-foreground text-sm">Información legal importante sobre el uso de Cepheus Transit.</p>
      </div>

      <div className="space-y-4">
        <Card className="border-none shadow-md bg-muted/20">
          <CardContent className="p-5">
            <h3 className="font-bold flex items-center gap-2 mb-2 text-primary">
              <Shield className="h-4 w-4" /> Propósito Informativo
            </h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              La aplicación "Cepheus Transit" tiene un carácter estrictamente informativo y pedagógico. La información aquí contenida <strong>no constituye asesoría legal, representación jurídica ni dictamen pericial vinculante</strong>.
            </p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-md bg-muted/20">
          <CardContent className="p-5">
            <h3 className="font-bold flex items-center gap-2 mb-2 text-primary">
              <AlertTriangle className="h-4 w-4" /> Variación Normativa
            </h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              La legislación de tránsito en Colombia (leyes, decretos, resoluciones) y la jurisprudencia de las altas cortes pueden cambiar, ser derogadas o modificadas sin previo aviso. Es responsabilidad del usuario verificar la vigencia de la información con fuentes oficiales (Diario Oficial, RUNT, Ministerio de Transporte).
            </p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-md bg-muted/20">
          <CardContent className="p-5">
            <h3 className="font-bold flex items-center gap-2 mb-2 text-primary">
              <Shield className="h-4 w-4" /> Herramientas Técnicas
            </h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              El Validador de Alcoholemia y otras herramientas técnicas proporcionan un análisis <strong>preliminar</strong> basado en promedios y estándares documentados (Resolución 181 de 2015 MinSalud). El resultado de la app no invalida un procedimiento oficial. Las objeciones a pruebas de alcoholemia deben realizarse dentro del proceso contravencional correspondiente mediante recursos legales.
            </p>
          </CardContent>
        </Card>

        <div className="mt-8 text-center text-xs text-muted-foreground pb-4 border-t border-border pt-6">
          <p>© {new Date().getFullYear()} Cepheus Transit.</p>
          <p className="mt-1">Desarrollado para la seguridad jurídica en vías de Colombia.</p>
        </div>
      </div>
    </div>
  );
}
